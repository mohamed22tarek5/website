@echo off
setlocal EnableExtensions EnableDelayedExpansion
title M.T.A. - Super Ultra Performance

REM ============================================================
REM  M.T.A. Super Ultra Performance - FUNCTION VERSION
REM ------------------------------------------------------------
REM  Standalone :  UltimatePerformance.bat
REM  As library :  call UltimatePerformance.bat :SuperUltra
REM                call UltimatePerformance.bat :SuperUltra dry  (no changes, test only)
REM  Embedded   :  copy :SuperUltra into your script and do  call :SuperUltra
REM ============================================================

REM --- Library dispatch (lets other .bat files call this file as a function lib) ---
REM NOTE: parens are required - `if cond cmd & goto` would run goto ALWAYS.
if /i "%~1"==":SuperUltra" (shift /1 & goto :SuperUltra)
if /i "%~1"==":EnsureAdmin" (shift /1 & goto :EnsureAdmin)
if /i "%~1"==":EnsureUltimatePlan" (shift /1 & goto :EnsureUltimatePlan)
if /i "%~1"==":ApplyUltraTweaks" (shift /1 & goto :ApplyUltraTweaks)
if /i "%~1"==":VerifyPlan" (shift /1 & goto :VerifyPlan)

REM --- Main (runs when double-clicked / run directly) ---
call :SuperUltra %*
set "RC=%ERRORLEVEL%"
echo.
if "%RC%"=="0" (
  echo [DONE] Super Ultra Performance applied. Reboot recommended.
) else (
  echo [FAIL] Something failed. Errorlevel=%RC%. Try Run as Administrator.
)
echo.
"%SystemRoot%\System32\timeout.exe" /t 3 >nul 2>&1
exit /b %RC%

REM ============================================================
REM :Init - resolve tool paths (never rely on PATH)
REM ============================================================
:Init
if not defined SystemRoot set "SystemRoot=C:\Windows"
set "POWERCFG=%SystemRoot%\System32\powercfg.exe"
set "REGEXE=%SystemRoot%\System32\reg.exe"
set "NETEXE=%SystemRoot%\System32\net.exe"
set "FINDEXE=%SystemRoot%\System32\find.exe"
set "TIMEOUTEXE=%SystemRoot%\System32\timeout.exe"
set "PSEXE=%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe"
if not exist "%POWERCFG%" set "POWERCFG=powercfg"
if not exist "%REGEXE%" set "REGEXE=reg"
if not exist "%NETEXE%" set "NETEXE=net"
if not exist "%FINDEXE%" set "FINDEXE=find"
if not exist "%TIMEOUTEXE%" set "TIMEOUTEXE=timeout"
if not exist "%PSEXE%" set "PSEXE=powershell"
exit /b 0

REM ============================================================
REM :SuperUltra [dry]
REM   Super-ultra wrapper. One call does everything.
REM   Arg: dry = print only, change nothing (safe test mode)
REM ============================================================
:SuperUltra
setlocal EnableDelayedExpansion
call :Init
set "DRY=0"
if /i "%~1"=="dry" set "DRY=1"
if /i "%~1"=="/dry" set "DRY=1"
if /i "%~1"=="test" set "DRY=1"

echo.
echo  ======================================================
echo   M.T.A. SUPER ULTRA PERFORMANCE  (function :SuperUltra)
echo  ======================================================
if "%DRY%"=="1" echo  [MODE] DRY-RUN - no changes will be made.
echo.

REM 1) Admin rights (skip check in dry-run)
if "%DRY%"=="0" (
  call :EnsureAdmin
  if errorlevel 3 (
    echo [INFO] Elevated copy launched - setup continues there.
    endlocal & exit /b 0
  )
  if errorlevel 1 (
    echo [FAIL] Admin rights required.
    endlocal & exit /b 1
  )
) else (
  echo [DRY ] would check: admin rights
)

REM 2) Make sure Ultimate Performance plan exists + activate it
call :EnsureUltimatePlan %~1
if errorlevel 1 (
  echo [FAIL] Could not create/activate Ultimate Performance plan.
  endlocal & exit /b 2
)

REM 3) Apply aggressive powercfg + registry tweaks
call :ApplyUltraTweaks %~1
if errorlevel 1 (
  echo [WARN] Plan is active but some tweaks failed.
  REM don't hard-fail, still verify
)

REM 4) Verify
call :VerifyPlan %~1
endlocal & exit /b 0

REM ============================================================
REM :EnsureAdmin
REM   Returns 0 if admin, else tries to self-elevate and returns 1.
REM ============================================================
:EnsureAdmin
call :Init
"%NETEXE%" session >nul 2>&1
if "%ERRORLEVEL%"=="0" (
  echo [OK  ] Running as Administrator.
  exit /b 0
)
echo [....] Not admin - requesting elevation...
"%PSEXE%" -NoProfile -NonInteractive -Command "Start-Process -FilePath '%~f0' -Verb RunAs" >nul 2>&1
if "%ERRORLEVEL%"=="0" (
  echo [INFO] Elevated copy launched. This window will close.
  "%TIMEOUTEXE%" /t 2 >nul 2>&1
  REM NOTE: /b on purpose - bare `exit` would kill a parent script
  REM when this file is used as a function library. 3 = relaunched.
  exit /b 3
)
echo [FAIL] Auto-elevate failed. Right-click -^> Run as administrator.
exit /b 1

REM ============================================================
REM :EnsureUltimatePlan [dry]
REM   Correct Ultimate GUID: e9a42b02-d5df-448d-aa00-03f14749eb61
REM   Legacy/wrong GUID from old script (kept for compat):
REM     280d3b04-57bb-4f34-ac49-4bd15f4c4b40
REM ============================================================
:EnsureUltimatePlan
setlocal EnableDelayedExpansion
call :Init
set "DRY=0"
if /i "%~1"=="dry" set "DRY=1"
set "ULTIMATE_GUID=e9a42b02-d5df-448d-aa00-03f14749eb61"
set "LEGACY_GUID=280d3b04-57bb-4f34-ac49-4bd15f4c4b40"

echo [....] Checking power plans...
if "%DRY%"=="1" (
  echo [DRY ] would run: powercfg /L
  echo [DRY ] would run: powercfg -duplicatescheme %ULTIMATE_GUID%
  echo [DRY ] would run: powercfg /setactive %ULTIMATE_GUID%
  endlocal & exit /b 0
)

"%POWERCFG%" /L | "%FINDEXE%" /i "%ULTIMATE_GUID%" >nul 2>&1
if "%ERRORLEVEL%"=="0" (
  echo [OK  ] Ultimate Performance plan found.
) else (
  echo [....] Ultimate plan missing - unlocking it...
  "%POWERCFG%" -duplicatescheme %ULTIMATE_GUID% >nul 2>&1
  REM Some OEM Windows builds hide it even after duplicate; second check:
  "%POWERCFG%" /L | "%FINDEXE%" /i "Ultimate Performance" >nul 2>&1
  if errorlevel 1 (
    echo [WARN] Duplicate did not show Ultimate Performance, retrying with High-Perf base...
    "%POWERCFG%" -duplicatescheme 8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c >nul 2>&1
    "%POWERCFG%" -duplicatescheme %ULTIMATE_GUID% >nul 2>&1
  )
)

REM Activate: prefer real Ultimate GUID, fall back to legacy GUID, fall back to SCHEME_MIN
"%POWERCFG%" /setactive %ULTIMATE_GUID% >nul 2>&1
if errorlevel 1 (
  echo [WARN] %ULTIMATE_GUID% failed, trying legacy %LEGACY_GUID%...
  "%POWERCFG%" /setactive %LEGACY_GUID% >nul 2>&1
)
if errorlevel 1 (
  echo [WARN] Legacy GUID failed too, trying SCHEME_MIN...
  "%POWERCFG%" /setactive SCHEME_MIN >nul 2>&1
)
if errorlevel 1 (
  echo [FAIL] Could not activate any performance plan.
  endlocal & exit /b 1
)
echo [OK  ] Performance plan activated.
endlocal & exit /b 0

REM ============================================================
REM :ApplyUltraTweaks [dry]
REM   Pushes every relevant powercfg value to MAX performance
REM   on AC + DC, plus registry anti-throttle switches.
REM   All per-setting errors are swallowed so one bad GUID
REM   can never abort the whole function.
REM ============================================================
:ApplyUltraTweaks
setlocal
call :Init
set "DRY=0"
if /i "%~1"=="dry" set "DRY=1"

echo [....] Applying SUPER ULTRA tweaks...

if "%DRY%"=="1" (
  echo [DRY ] would set: CPU 100%%/100%%, cooling Active, boost Aggressive
  echo [DRY ] would set: disk/sleep/hibernate/monitor timeouts = 0 (never)
  echo [DRY ] would set: USB suspend OFF, PCIe LinkState OFF, WiFi Max Perf
  echo [DRY ] would run: powercfg -h off + registry PowerThrottlingOff=1
  echo [DRY ] would run: powercfg /setactive SCHEME_CURRENT
  endlocal & exit /b 0
)

REM -- Helper: both AC and DC at once --
REM CPU: min 100%% / max 100%% / cooling ACTIVE / boost AGGRESSIVE / disable idle
call :SetPow 54533251-82be-4824-96c1-47b60b740d00 893dee8e-2cbf-41e0-9f29-0916f886fe3 100 "CPU MIN 100%%"
call :SetPow 54533251-82be-4824-96c1-47b60b740d00 bc5038f7-23e0-4960-887c-15b5db4c201 100 "CPU MAX 100%%"
call :SetPow 54533251-82be-4824-96c1-47b60b740d00 94d3a615-a899-4ac5-ae2b-e4d8f634367f 1   "Cooling ACTIVE"
call :SetPow 54533251-82be-4824-96c1-47b60b740d00 be337238-0d82-4146-a960-4f4379b1c33 2   "Boost AGGRESSIVE"
call :SetPow 54533251-82be-4824-96c1-47b60b740d00 5d76a2ca-e8c0-402b-a133-215a86b9040 1   "CPU idle DISABLE"
call :SetPow 54533251-82be-4824-96c1-47b60b740d00 0cc5b647-c1df-4637-891a-dec35c318583 100 "Core parking MIN 100%%"
call :SetPow 54533251-82be-4824-96c1-47b60b740d00 80d4ff86-9fd0-4e38-95da-404717c2857 0   "Core parking decrease 0"

REM Disk: never turn off (0)
call :SetPow 0012ee47-9041-4b5d-9b77-535fba8b1442 6738e2c4-e8a5-4a42-b16a-e042a502e276 0 "HDD never off"

REM Sleep/standby/hibernate/hybrid: never (0)
call :SetPow 238c9fa8-0aad-41d5-88ff-096e57a77d2 29f6c1db-86da-48c5-9fdb-d6d88f2c670 0 "Sleep NEVER"
call :SetPow 238c9fa8-0aad-41d5-88ff-096e57a77d2 9d7815a6-7ee4-497e-8881-515d05c92b 0 "Hibernate NEVER"
call :SetPow 238c9fa8-0aad-41d5-88ff-096e57a77d2 94ac6d29-73a4-41a6-809d-446785d64d 0 "Hybrid sleep OFF"

REM Display / video idle: never (0)
call :SetPow 7516b95f-f776-4464-8c53-06167f40cc5 3c0bc021-c8a8-4e44-8531-7017f864bc3 0 "Display NEVER"
"%POWERCFG%" /change monitor-timeout-ac 0 >nul 2>&1
"%POWERCFG%" /change monitor-timeout-dc 0 >nul 2>&1
"%POWERCFG%" /change standby-timeout-ac 0 >nul 2>&1
"%POWERCFG%" /change standby-timeout-dc 0 >nul 2>&1
"%POWERCFG%" /change disk-timeout-ac 0 >nul 2>&1
"%POWERCFG%" /change disk-timeout-dc 0 >nul 2>&1

REM USB selective suspend: DISABLED (0)
call :SetPow 2a737441-1930-4402-8d77-b2bebba30871 48e6b7a6-50f5-4782-a5d4-53bb8f07e226 0 "USB suspend OFF"

REM PCI Express Link State: OFF (0)
call :SetPow 501a4d13-42af-4429-9fd1-a6dc8c319f ee12f906-d277-404b-b6da-e5fa1a576df 0 "PCIe LinkState OFF"

REM Wi-Fi: Maximum Performance (1)
call :SetPow 19cbb8fa-5279-450e-9fac-8a3d5fedd0 12bbebe6-58d6-4636-95bb-3217ef867c 1 "WiFi MAX PERF"

REM Lid close / power buttons: do nothing on AC (0) so perf never interrupts
"%POWERCFG%" /SETACVALUEINDEX SCHEME_CURRENT 4f971e89-eebd-4455-a8de-9e59040e7347 5ca83367-51e3-4f20-ba12-a6f29353e955 0 >nul 2>&1
"%POWERCFG%" /SETDCVALUEINDEX SCHEME_CURRENT 4f971e89-eebd-4455-a8de-9e59040e7347 5ca83367-51e3-4f20-ba12-a6f29353e955 0 >nul 2>&1

REM Disable hibernation file (kills hidden sleep latency + frees GBs)
"%POWERCFG%" -h off >nul 2>&1

REM Registry: kill Windows power throttling
"%REGEXE%" add "HKLM\SYSTEM\CurrentControlSet\Control\Power\PowerThrottling" /v "PowerThrottlingOff" /t REG_DWORD /d 1 /f >nul 2>&1
if "%ERRORLEVEL%"=="0" (echo [OK  ] PowerThrottling OFF) else (echo [WARN] PowerThrottling reg blocked)

REM Commit everything to the active scheme
"%POWERCFG%" /setactive SCHEME_CURRENT >nul 2>&1
echo [OK  ] SUPER ULTRA tweaks applied.
endlocal & exit /b 0

REM ============================================================
REM :SetPow <SubGUID> <SettingGUID> <Value> <Label>
REM   Internal helper - sets AC + DC, never fails the caller.
REM ============================================================
:SetPow
if not defined POWERCFG call :Init
"%POWERCFG%" /SETACVALUEINDEX SCHEME_CURRENT %~1 %~2 %~3 >nul 2>&1
"%POWERCFG%" /SETDCVALUEINDEX SCHEME_CURRENT %~1 %~2 %~3 >nul 2>&1
if "%ERRORLEVEL%"=="0" (echo [OK  ] %~4) else (echo [WARN] %~4 skipped)
exit /b 0

REM ============================================================
REM :VerifyPlan [dry]
REM ============================================================
:VerifyPlan
call :Init
if /i "%~1"=="dry" (
  echo.
  echo [DRY ] would run: powercfg /getactivescheme
  exit /b 0
)
echo.
echo [....] Active scheme now:
"%POWERCFG%" /getactivescheme
exit /b 0
