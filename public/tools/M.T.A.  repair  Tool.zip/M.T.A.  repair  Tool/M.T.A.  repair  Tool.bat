@echo off
setlocal enabledelayedexpansion

:: ============================================================
::  M.T.A. REPAIR TOOL - PRO v2.0
::  Windows System Repair Utility
:: ============================================================

title M.T.A. Repair Tool v2.0 PRO
color 0B

:: ---------- Auto-Elevate to Admin ----------
net session >nul 2>&1
if %errorlevel% neq 0 (
    echo Requesting Administrator privileges...
    powershell -Command "Start-Process '%~f0' -Verb RunAs"
    exit /b
)

:: ---------- Setup Logging ----------
set TIMESTAMP=unknown
for /f "tokens=2 delims==" %%I in ('wmic os get localdatetime /value 2^>nul') do set DATETIME=%%I
if defined DATETIME (
    set TIMESTAMP=!DATETIME:~0,8!_!DATETIME:~8,6!
) else (
    for /f %%I in ('powershell -NoProfile -Command "Get-Date -Format 'yyyyMMdd_HHmmss'"') do set TIMESTAMP=%%I
)
set LOGFILE=%USERPROFILE%\Desktop\MTA_Repair_!TIMESTAMP!.log

echo M.T.A. Repair Log - !DATE! !TIME! > "!LOGFILE!"
echo =========================================== >> "!LOGFILE!"

:: ---------- Restore Point (safety) ----------
echo Creating system restore point...
powershell -Command "Checkpoint-Computer -Description 'MTA Repair Tool' -RestorePointType 'MODIFY_SETTINGS'" >> "!LOGFILE!" 2>&1

:MENU
cls
echo.
echo  ███╗   ███╗   ████████╗    █████╗
echo  ████╗ ████║   ╚══██╔══╝   ██╔══██╗
echo  ██╔████╔██║      ██║      ███████║
echo  ██║╚██╔╝██║      ██║      ██╔══██║
echo  ██║ ╚═╝ ██║      ██║      ██║  ██║
echo  ╚═╝     ╚═╝      ╚═╝      ╚═╝  ╚═╝
echo.
echo       M.T.A.  REPAIR TOOL  v2.0  PRO
echo  ========================================
echo   Log: !LOGFILE!
echo  ========================================
echo.
echo   [1] Full Auto Repair  (Recommended)
echo   [2] DISM Image Repair Only
echo   [3] SFC System File Check Only
echo   [4] Disk Check (CHKDSK) Only
echo   [5] Network Reset (DNS / Winsock / IP)
echo   [6] Temp Files Cleanup
echo   [7] Fix Windows Update
echo   [8] System Health Report
echo   [0] Exit
echo.
set /p CHOICE="  Select option [0-8]: "

if "%CHOICE%"=="1" goto FULL
if "%CHOICE%"=="2" (call :DISM & goto PAUSE_RETURN)
if "%CHOICE%"=="3" (call :SFC & goto PAUSE_RETURN)
if "%CHOICE%"=="4" (call :CHKDSK & goto PAUSE_RETURN)
if "%CHOICE%"=="5" (call :NETWORK & goto PAUSE_RETURN)
if "%CHOICE%"=="6" (call :CLEANUP & goto PAUSE_RETURN)
if "%CHOICE%"=="7" (call :WUFIX & goto PAUSE_RETURN)
if "%CHOICE%"=="8" (call :REPORT & goto PAUSE_RETURN)
if "%CHOICE%"=="0" goto END
echo Invalid choice. Try again.
timeout /t 1 >nul
goto MENU

:: ================= FULL REPAIR =================
:FULL
call :DISM
call :SFC
call :CHKDSK_SCAN
call :CLEANUP
call :NETWORK
echo.
echo [OK] Full repair completed. Check log: !LOGFILE!
echo Restart recommended.
echo [OK] Full repair completed. >> "!LOGFILE!"
goto PAUSE_RETURN

:PAUSE_RETURN
echo.
echo ----------------------------------------
echo Done. Log saved to: !LOGFILE!
echo ----------------------------------------
pause
goto MENU

:: ================= MODULES =================
:DISM
echo.
echo === [1/5] DISM IMAGE REPAIR ===
echo === DISM START %DATE% %TIME% === >> "!LOGFILE!"
set "MTA_LOG=!LOGFILE!"
echo -- CheckHealth...
DISM /Online /Cleanup-Image /CheckHealth 2>&1 | powershell -NoProfile -Command "$input | Tee-Object -Append -FilePath $env:MTA_LOG"
echo -- ScanHealth...
DISM /Online /Cleanup-Image /ScanHealth 2>&1 | powershell -NoProfile -Command "$input | Tee-Object -Append -FilePath $env:MTA_LOG"
echo -- RestoreHealth... (this takes 10-20 min, please wait)
DISM /Online /Cleanup-Image /RestoreHealth 2>&1 | powershell -NoProfile -Command "$input | Tee-Object -Append -FilePath $env:MTA_LOG"
echo -- Component Cleanup...
DISM /Online /Cleanup-Image /StartComponentCleanup 2>&1 | powershell -NoProfile -Command "$input | Tee-Object -Append -FilePath $env:MTA_LOG"
if !errorlevel! neq 0 (
    echo [!] DISM reported errors. See log. >> "!LOGFILE!"
    echo [!] DISM completed with warnings - check log.
) else (
    echo [OK] DISM completed successfully.
    echo [OK] DISM completed. >> "!LOGFILE!"
)
exit /b 0

:SFC
echo.
echo === [2/5] SFC SYSTEM FILE CHECK ===
echo === SFC START %DATE% %TIME% === >> "!LOGFILE!"
set "MTA_LOG=!LOGFILE!"
sfc /scannow 2>&1 | powershell -NoProfile -Command "$input | Tee-Object -Append -FilePath $env:MTA_LOG"
if !errorlevel! neq 0 (
    echo [!] SFC found unrepaired files. Check C:\Windows\Logs\CBS\CBS.log >> "!LOGFILE!"
    echo [!] SFC found issues. Run Full Repair again after reboot.
) else (
    echo [OK] SFC completed.
)
exit /b 0

:CHKDSK
:CHKDSK_SCAN
echo.
echo === [3/5] DISK CHECK ===
echo === CHKDSK START %DATE% %TIME% === >> "!LOGFILE!"
set "MTA_LOG=!LOGFILE!"
chkdsk C: /scan 2>&1 | powershell -NoProfile -Command "$input | Tee-Object -Append -FilePath $env:MTA_LOG"
if !errorlevel! neq 0 (
    echo [!] Disk errors detected.
    set /p FIXDISK="Schedule CHKDSK /F on next reboot? [Y/N]: "
    if /i "!FIXDISK!"=="Y" (
        echo Y | chkdsk C: /f 2>&1 | powershell -NoProfile -Command "$input | Tee-Object -Append -FilePath $env:MTA_LOG"
        echo Scheduled. Will run on reboot.
    )
) else (
    echo [OK] No disk errors found.
    echo [OK] CHKDSK clean. >> "!LOGFILE!"
)
exit /b 0

:NETWORK
echo.
echo === NETWORK RESET ===
echo === NET RESET %DATE% %TIME% === >> "!LOGFILE!"
set "MTA_LOG=!LOGFILE!"
ipconfig /flushdns 2>&1 | powershell -NoProfile -Command "$input | Tee-Object -Append -FilePath $env:MTA_LOG"
netsh winsock reset 2>&1 | powershell -NoProfile -Command "$input | Tee-Object -Append -FilePath $env:MTA_LOG"
netsh int ip reset 2>&1 | powershell -NoProfile -Command "$input | Tee-Object -Append -FilePath $env:MTA_LOG"
ipconfig /release 2>&1 | powershell -NoProfile -Command "$input | Tee-Object -Append -FilePath $env:MTA_LOG"
ipconfig /renew 2>&1 | powershell -NoProfile -Command "$input | Tee-Object -Append -FilePath $env:MTA_LOG"
echo [OK] Network stack reset. Reboot required for full effect.
echo [OK] Network reset done. >> "!LOGFILE!"
exit /b 0

:CLEANUP
echo.
echo === TEMP CLEANUP ===
echo === CLEANUP %DATE% %TIME% === >> "!LOGFILE!"
echo Cleaning Temp, Prefetch, SoftwareDistribution cache...
del /q /f /s "%TEMP%\*" 2>nul >> "!LOGFILE!" 2>&1
del /q /f /s "C:\Windows\Temp\*" 2>nul >> "!LOGFILE!" 2>&1
del /q /f /s "C:\Windows\Prefetch\*" 2>nul >> "!LOGFILE!" 2>&1
cleanmgr /verylowdisk 2>nul
DISM /Online /Cleanup-Image /StartComponentCleanup /ResetBase >> "!LOGFILE!" 2>&1
echo [OK] Cleanup done.
exit /b 0

:WUFIX
echo.
echo === FIX WINDOWS UPDATE ===
echo === WU FIX %DATE% %TIME% === >> "!LOGFILE!"
echo Stopping services...
net stop wuauserv >> "!LOGFILE!" 2>&1
net stop cryptSvc >> "!LOGFILE!" 2>&1
net stop bits >> "!LOGFILE!" 2>&1
net stop msiserver >> "!LOGFILE!" 2>&1
if exist C:\Windows\SoftwareDistribution.old rmdir /s /q C:\Windows\SoftwareDistribution.old 2>>"!LOGFILE!"
if exist C:\Windows\System32\catroot2.old rmdir /s /q C:\Windows\System32\catroot2.old 2>>"!LOGFILE!"
ren C:\Windows\SoftwareDistribution SoftwareDistribution.old 2>>"!LOGFILE!"
ren C:\Windows\System32\catroot2 catroot2.old 2>>"!LOGFILE!"
echo Starting services...
net start wuauserv >> "!LOGFILE!" 2>&1
net start cryptSvc >> "!LOGFILE!" 2>&1
net start bits >> "!LOGFILE!" 2>&1
net start msiserver >> "!LOGFILE!" 2>&1
wuauclt /resetauthorization /detectnow 2>nul >> "!LOGFILE!" 2>&1
echo [OK] Windows Update components reset.
exit /b 0

:REPORT
echo.
echo === SYSTEM HEALTH REPORT ===
echo === REPORT %DATE% %TIME% === >> "!LOGFILE!"
systeminfo | findstr /C:"OS Name" /C:"OS Version" /C:"System Type" /C:"Total Physical Memory"
ver >> "!LOGFILE!" 2>&1
systeminfo >> "!LOGFILE!" 2>&1
echo.
sfc /verifyonly
DISM /Online /Cleanup-Image /CheckHealth
echo.
echo Report appended to log.
exit /b 0

:END
echo.
echo Log saved to: !LOGFILE!
echo Thanks for using M.T.A. Repair Tool PRO.
timeout /t 2 >nul
exit /b 0
