@echo off
title Network Adapter Information
echo =============================================
echo       Network Adapter IP and MAC Address      
echo =============================================
echo made by: mohamed tarek
echo.
echo [SYSTEM]
echo     Computer Name: %COMPUTERNAME%
echo     User Name: %USERNAME%
echo     Date: %DATE%  Time: %TIME%
echo.
echo.
rem Get Adapter Description
echo Adapter Name:
for /f "tokens=1* delims=:" %%A in ('ipconfig ^| findstr /i "adapter"') do echo     %%A %%B
echo.
echo.
rem Paired IP + MAC per adapter - table view
echo [IP + MAC Together - Per Adapter]:
powershell -NoProfile -ExecutionPolicy Bypass -Command "Get-CimInstance Win32_NetworkAdapterConfiguration -Filter 'IPEnabled=TRUE' ^| Select-Object @{n='Adapter';e={$_.Description}}, @{n='MAC';e={$_.MACAddress}}, @{n='IP';e={$_.IPAddress -join ', '}}, @{n='Gateway';e={$_.DefaultIPGateway -join ', '}}, @{n='DNS';e={$_.DNSServerSearchOrder -join ', '}} ^| Format-Table -AutoSize -Wrap"
echo.
echo.
echo [IP Address - IPv4]:
for /f "tokens=2 delims=:" %%A in ('ipconfig ^| findstr /i "IPv4"') do for /f "tokens=* delims= " %%B in ("%%A") do echo     %%B
echo.
echo [IP Address - IPv6]:
for /f "tokens=2 delims=:" %%A in ('ipconfig ^| findstr /i "IPv6"') do for /f "tokens=* delims= " %%B in ("%%A") do echo     %%B
echo.
echo [Subnet Mask]:
for /f "tokens=2 delims=:" %%A in ('ipconfig ^| findstr /i "Subnet"') do for /f "tokens=* delims= " %%B in ("%%A") do echo     %%B
echo.
echo [Default Gateway]:
for /f "tokens=2 delims=:" %%A in ('ipconfig ^| findstr /i "Gateway"') do for /f "tokens=* delims= " %%B in ("%%A") do if not "%%B"=="" echo     %%B
echo.
echo [DNS Servers]:
ipconfig /all ^| findstr /i "DNS Servers"
echo.
rem Get MAC Address - /v shows adapter name, /nh skips header (fixes old Physical bug)
echo [MAC Address + Connection Status]:
getmac /v /nh /fo table
echo.
echo [Full Details - Description / DHCP / Physical]:
ipconfig /all ^| findstr /i "Description Physical DHCP IPv4 Subnet Gateway DNS"

echo.
echo =============================================
echo             End of Information               
echo =============================================

pause
