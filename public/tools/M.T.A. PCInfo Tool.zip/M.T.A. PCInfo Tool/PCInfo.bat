@echo off
setlocal EnableDelayedExpansion
title System Hardware Information - DO NOT CLOSE
color 1F
echo ===============================================
echo BASIC HARDWARE INFORMATION - By @m.t.a.
echo ===============================================
echo.
echo Creating log file...
set "logfile=%USERPROFILE%\Desktop\basic_hardware_info.txt"
echo Windows Hardware Information > "%logfile%"
echo Generated: %DATE% %TIME% >> "%logfile%"
echo. >> "%logfile%"
echo --- COMPUTER INFORMATION ---
echo --- COMPUTER INFORMATION --- >> "%logfile%"
systeminfo | findstr /B /C:"Host Name" /C:"OS Name" /C:"OS Version" /C:"System Manufacturer" /C:"System Model" /C:"System Type" /C:"Total Physical Memory"
systeminfo | findstr /B /C:"Host Name" /C:"OS Name" /C:"OS Version" /C:"System Manufacturer" /C:"System Model" /C:"System Type" /C:"Total Physical Memory" >> "%logfile%"
echo OS Build / Edition / Architecture:
echo OS Build / Edition / Architecture: >> "%logfile%"
powershell -command "$os = Get-CimInstance Win32_OperatingSystem; Write-Host ($os.Caption + ' | Version ' + $os.Version + ' Build ' + $os.BuildNumber + ' | ' + $os.OSArchitecture)"
powershell -command "$logPath = '%logfile%'; $os = Get-CimInstance Win32_OperatingSystem; Add-Content -Path $logPath -Value ($os.Caption + ' | Version ' + $os.Version + ' Build ' + $os.BuildNumber + ' | ' + $os.OSArchitecture)"
echo Registered User:
powershell -command "$os = Get-CimInstance Win32_OperatingSystem; Write-Host $os.RegisteredUser"
powershell -command "$logPath = '%logfile%'; $os = Get-CimInstance Win32_OperatingSystem; Add-Content -Path $logPath -Value ('Registered User: ' + $os.RegisteredUser)"
echo Windows Installation Date:
powershell -command "$os = Get-WmiObject Win32_OperatingSystem; $installDate = [Management.ManagementDateTimeConverter]::ToDateTime($os.InstallDate); Write-Host $installDate.ToString('yyyy-MM-dd HH:mm:ss')"
powershell -command "$logPath = '%logfile%'; $os = Get-WmiObject Win32_OperatingSystem; $installDate = [Management.ManagementDateTimeConverter]::ToDateTime($os.InstallDate); Add-Content -Path $logPath -Value ('Windows Installation Date: ' + $installDate.ToString('yyyy-MM-dd HH:mm:ss'))"
echo Last Boot Time / Uptime:
echo Last Boot Time / Uptime: >> "%logfile%"
powershell -command "$os = Get-CimInstance Win32_OperatingSystem; $up = (Get-Date) - $os.LastBootUpTime; Write-Host ('Last Boot : ' + $os.LastBootUpTime.ToString('yyyy-MM-dd HH:mm:ss')); Write-Host ('Uptime    : ' + $up.Days + ' days ' + $up.Hours + 'h ' + $up.Minutes + 'm')"
powershell -command "$logPath = '%logfile%'; $os = Get-CimInstance Win32_OperatingSystem; $up = (Get-Date) - $os.LastBootUpTime; Add-Content -Path $logPath -Value ('Last Boot : ' + $os.LastBootUpTime.ToString('yyyy-MM-dd HH:mm:ss')); Add-Content -Path $logPath -Value ('Uptime    : ' + $up.Days + ' days ' + $up.Hours + 'h ' + $up.Minutes + 'm')"
echo TimeZone / Locale:
echo TimeZone / Locale: >> "%logfile%"
powershell -command "$tz = Get-CimInstance Win32_TimeZone; Write-Host ('TimeZone : ' + $tz.Caption)"
powershell -command "$logPath = '%logfile%'; $tz = Get-CimInstance Win32_TimeZone; Add-Content -Path $logPath -Value ('TimeZone : ' + $tz.Caption)"
powershell -command "Get-Culture | ForEach-Object { Write-Host ('Locale   : ' + $_.Name + ' (' + $_.DisplayName + ')') }"
powershell -command "$logPath = '%logfile%'; Get-Culture | ForEach-Object { Add-Content -Path $logPath -Value ('Locale   : ' + $_.Name + ' (' + $_.DisplayName + ')') }"
echo Domain / Workgroup:
echo Domain / Workgroup: >> "%logfile%"
powershell -command "$cs = Get-CimInstance Win32_ComputerSystem; Write-Host ('Domain: ' + $cs.Domain + ' | Workgroup: ' + $cs.Workgroup + ' | PartOfDomain: ' + $cs.PartOfDomain)"
powershell -command "$logPath = '%logfile%'; $cs = Get-CimInstance Win32_ComputerSystem; Add-Content -Path $logPath -Value ('Domain: ' + $cs.Domain + ' | Workgroup: ' + $cs.Workgroup + ' | PartOfDomain: ' + $cs.PartOfDomain)"
echo Virtualization (Firmware):
echo Virtualization (Firmware): >> "%logfile%"
powershell -command "$p = Get-CimInstance Win32_Processor | Select-Object -First 1; Write-Host ('VirtualizationFirmwareEnabled : ' + $p.VirtualizationFirmwareEnabled)"
powershell -command "$logPath = '%logfile%'; $p = Get-CimInstance Win32_Processor | Select-Object -First 1; Add-Content -Path $logPath -Value ('VirtualizationFirmwareEnabled : ' + $p.VirtualizationFirmwareEnabled)"
echo BIOS Release Date:
powershell -command "$bios = Get-WmiObject Win32_BIOS; $biosDate = [Management.ManagementDateTimeConverter]::ToDateTime($bios.ReleaseDate); Write-Host $biosDate.ToString('yyyy-MM-dd')"
powershell -command "$logPath = '%logfile%'; $bios = Get-WmiObject Win32_BIOS; $biosDate = [Management.ManagementDateTimeConverter]::ToDateTime($bios.ReleaseDate); Add-Content -Path $logPath -Value ('BIOS Release Date: ' + $biosDate.ToString('yyyy-MM-dd'))"
echo.
echo. >> "%logfile%"
echo --- CPU INFORMATION ---
echo --- CPU INFORMATION --- >> "%logfile%"
echo CPU Model:
wmic cpu get name
wmic cpu get name >> "%logfile%"
echo.
echo CPU Details:
wmic cpu get NumberOfCores, NumberOfLogicalProcessors, MaxClockSpeed
wmic cpu get NumberOfCores, NumberOfLogicalProcessors, MaxClockSpeed >> "%logfile%"
echo CPU Cache / Socket / Load:
echo CPU Cache / Socket / Load: >> "%logfile%"
powershell -command "Get-CimInstance Win32_Processor | ForEach-Object { Write-Host ('Cores: ' + $_.NumberOfCores + ' Threads: ' + $_.NumberOfLogicalProcessors + ' Max: ' + $_.MaxClockSpeed + ' MHz | L2: ' + $_.L2CacheSize + ' KB L3: ' + $_.L3CacheSize + ' KB | Socket: ' + $_.SocketDesignation) }"
powershell -command "$logPath = '%logfile%'; Get-CimInstance Win32_Processor | ForEach-Object { Add-Content -Path $logPath -Value ('Cores: ' + $_.NumberOfCores + ' Threads: ' + $_.NumberOfLogicalProcessors + ' Max: ' + $_.MaxClockSpeed + ' MHz | L2: ' + $_.L2CacheSize + ' KB L3: ' + $_.L3CacheSize + ' KB | Socket: ' + $_.SocketDesignation) }"
powershell -command "Get-CimInstance Win32_Processor | ForEach-Object { Write-Host ('Current Load: ' + $_.LoadPercentage + ' %% | Architecture: ' + $_.Architecture + ' | Status: ' + $_.Status) }"
powershell -command "$logPath = '%logfile%'; Get-CimInstance Win32_Processor | ForEach-Object { Add-Content -Path $logPath -Value ('Current Load: ' + $_.LoadPercentage + ' %% | Architecture: ' + $_.Architecture + ' | Status: ' + $_.Status) }"
echo.
echo. >> "%logfile%"
echo --- RAM INFORMATION ---
echo --- RAM INFORMATION --- >> "%logfile%"
echo Total RAM:
for /f "tokens=2 delims=:" %%a in ('systeminfo ^| findstr /C:"Total Physical Memory"') do (
    for /f "tokens=1" %%b in ("%%a") do echo %%b GB
    for /f "tokens=1" %%b in ("%%a") do echo %%b GB >> "%logfile%"
)
echo.
echo Memory Usage (Total / Used / Free):
echo Memory Usage (Total / Used / Free): >> "%logfile%"
powershell -command "$os=Get-CimInstance Win32_OperatingSystem; $total=[math]::Round($os.TotalVisibleMemorySize/1MB,2); $free=[math]::Round($os.FreePhysicalMemory/1MB,2); $used=[math]::Round($total-$free,2); $pct=[math]::Round($used/$total*100,1); Write-Host ('Total: ' + $total + ' GB  Used: ' + $used + ' GB  Free: ' + $free + ' GB  Usage: ' + $pct + ' %%')"
powershell -command "$logPath = '%logfile%'; $os=Get-CimInstance Win32_OperatingSystem; $total=[math]::Round($os.TotalVisibleMemorySize/1MB,2); $free=[math]::Round($os.FreePhysicalMemory/1MB,2); $used=[math]::Round($total-$free,2); $pct=[math]::Round($used/$total*100,1); Add-Content -Path $logPath -Value ('Total: ' + $total + ' GB  Used: ' + $used + ' GB  Free: ' + $free + ' GB  Usage: ' + $pct + ' %%')"
echo.
echo Memory Slots (Used / Total):
echo Memory Slots (Used / Total): >> "%logfile%"
powershell -command "$arr=Get-CimInstance Win32_PhysicalMemoryArray | Select-Object -First 1; $used=(Get-CimInstance Win32_PhysicalMemory).Count; if($used -is [array]){$used=$used.Count}; Write-Host ('Slots Used: ' + $used + ' / ' + $arr.MemoryDevices + ' | Max Capacity: ' + [math]::Round($arr.MaxCapacity/1MB,2) + ' GB')"
powershell -command "$logPath = '%logfile%'; $arr=Get-CimInstance Win32_PhysicalMemoryArray | Select-Object -First 1; $used=(Get-CimInstance Win32_PhysicalMemory).Count; if($used -is [array]){$used=$used.Count}; Add-Content -Path $logPath -Value ('Slots Used: ' + $used + ' / ' + $arr.MemoryDevices + ' | Max Capacity: ' + [math]::Round($arr.MaxCapacity/1MB,2) + ' GB')"
echo.
echo RAM Details (per stick - Size / Speed / DDR Type / Vendor):
echo Capacity    Speed    Type    Vendor/PartNo    Slot >> "%logfile%"
powershell -command "$map=@{20='DDR';21='DDR2';24='DDR3';26='DDR4';30='DDR5';31='LPDDR5';27='LPDDR';28='LPDDR2';29='LPDDR3'}; Get-CimInstance Win32_PhysicalMemory | ForEach-Object { $cap=[math]::Round($_.Capacity/1GB,2); $t=$_.SMBIOSMemoryType; if($t -is [array]){$t=$t[0]}; $ddr=if($map.ContainsKey([int]$t)){$map[[int]$t]}else{'Type-'+$t}; Write-Host ($cap.ToString() + ' GB | ' + $_.Speed + ' MHz (Cfg ' + $_.ConfiguredClockSpeed + ' MHz) | ' + $ddr + ' | ' + $_.Manufacturer.Trim() + ' ' + $_.PartNumber.Trim() + ' | ' + $_.DeviceLocator + ' ' + $_.BankLabel) }"
powershell -command "$logPath = '%logfile%'; $map=@{20='DDR';21='DDR2';24='DDR3';26='DDR4';30='DDR5';31='LPDDR5';27='LPDDR';28='LPDDR2';29='LPDDR3'}; Get-CimInstance Win32_PhysicalMemory | ForEach-Object { $cap=[math]::Round($_.Capacity/1GB,2); $t=$_.SMBIOSMemoryType; if($t -is [array]){$t=$t[0]}; $ddr=if($map.ContainsKey([int]$t)){$map[[int]$t]}else{'Type-'+$t}; Add-Content -Path $logPath -Value ($cap.ToString() + ' GB | ' + $_.Speed + ' MHz (Cfg ' + $_.ConfiguredClockSpeed + ' MHz) | ' + $ddr + ' | ' + $_.Manufacturer.Trim() + ' ' + $_.PartNumber.Trim() + ' | ' + $_.DeviceLocator + ' ' + $_.BankLabel) }"
echo.
echo. >> "%logfile%"
echo --- GPU / DISPLAY INFORMATION ---
echo --- GPU / DISPLAY INFORMATION --- >> "%logfile%"
echo Video Controller Details:
echo Name    VRAM (GB)    Driver Version
echo Name    VRAM (GB)    Driver Version >> "%logfile%"
powershell -command "$gpus = Get-WmiObject -Class 'Win32_VideoController'; foreach($gpu in $gpus) { if($gpu.AdapterRAM -ne $null) { $vramGB = [math]::Round($gpu.AdapterRAM / 1GB, 2); Write-Host $gpu.Name '    ' $vramGB ' GB    ' $gpu.DriverVersion } else { Write-Host $gpu.Name '    N/A    ' $gpu.DriverVersion }}"
powershell -command "$logPath = '%logfile%'; $gpus = Get-WmiObject -Class 'Win32_VideoController'; foreach($gpu in $gpus) { if($gpu.AdapterRAM -ne $null) { $vramGB = [math]::Round($gpu.AdapterRAM / 1GB, 2); Add-Content -Path $logPath -Value ($gpu.Name + '    ' + $vramGB + ' GB    ' + $gpu.DriverVersion) } else { Add-Content -Path $logPath -Value ($gpu.Name + '    N/A    ' + $gpu.DriverVersion) }}"
echo.
echo GPU Extended (Resolution / Refresh / Driver Date / Status):
echo GPU Extended (Resolution / Refresh / Driver Date / Status): >> "%logfile%"
powershell -command "Get-CimInstance Win32_VideoController | ForEach-Object { $d=[Management.ManagementDateTimeConverter]::ToDateTime($_.DriverDate); Write-Host ($_.Name + ' | ' + $_.CurrentHorizontalResolution + 'x' + $_.CurrentVerticalResolution + ' @ ' + $_.CurrentRefreshRate + 'Hz | Driver ' + $_.DriverVersion + ' (' + $d.ToString('yyyy-MM-dd') + ') | ' + $_.Status) }"
powershell -command "$logPath = '%logfile%'; Get-CimInstance Win32_VideoController | ForEach-Object { $d=[Management.ManagementDateTimeConverter]::ToDateTime($_.DriverDate); Add-Content -Path $logPath -Value ($_.Name + ' | ' + $_.CurrentHorizontalResolution + 'x' + $_.CurrentVerticalResolution + ' @ ' + $_.CurrentRefreshRate + 'Hz | Driver ' + $_.DriverVersion + ' (' + $d.ToString('yyyy-MM-dd') + ') | ' + $_.Status) }"
echo.
echo Current Display Resolution:
echo Current Display Resolution: >> "%logfile%"
powershell -command "Add-Type -AssemblyName System.Windows.Forms; $s=[System.Windows.Forms.Screen]::PrimaryScreen.Bounds; Write-Host ('Primary Display: ' + $s.Width + 'x' + $s.Height); Get-CimInstance Win32_VideoController | ForEach-Object { Write-Host ('Mode: ' + $_.VideoModeDescription) }"
powershell -command "$logPath = '%logfile%'; Add-Type -AssemblyName System.Windows.Forms; $s=[System.Windows.Forms.Screen]::PrimaryScreen.Bounds; Add-Content -Path $logPath -Value ('Primary Display: ' + $s.Width + 'x' + $s.Height); Get-CimInstance Win32_VideoController | ForEach-Object { Add-Content -Path $logPath -Value ('Mode: ' + $_.VideoModeDescription) }"
echo.
echo Monitors Detected:
echo Monitors Detected: >> "%logfile%"
powershell -command "Get-CimInstance Win32_DesktopMonitor | Where-Object { $_.ScreenWidth -ne $null } | ForEach-Object { Write-Host ($_.Name + ' | ' + $_.MonitorType + ' | ' + $_.ScreenWidth + 'x' + $_.ScreenHeight) }"
powershell -command "$logPath = '%logfile%'; Get-CimInstance Win32_DesktopMonitor | Where-Object { $_.ScreenWidth -ne $null } | ForEach-Object { Add-Content -Path $logPath -Value ($_.Name + ' | ' + $_.MonitorType + ' | ' + $_.ScreenWidth + 'x' + $_.ScreenHeight) }"
powershell -command "Get-CimInstance -Namespace root/wmi -Class WmiMonitorID | ForEach-Object { $m=($_.ManufacturerName | Where-Object { $_ -ne 0 } | ForEach-Object { [char]$_ }) -join ''; $n=($_.UserFriendlyName | Where-Object { $_ -ne 0 } | ForEach-Object { [char]$_ }) -join ''; Write-Host ('Monitor HW: ' + $m + ' ' + $n) }"
powershell -command "$logPath = '%logfile%'; Get-CimInstance -Namespace root/wmi -Class WmiMonitorID | ForEach-Object { $m=($_.ManufacturerName | Where-Object { $_ -ne 0 } | ForEach-Object { [char]$_ }) -join ''; $n=($_.UserFriendlyName | Where-Object { $_ -ne 0 } | ForEach-Object { [char]$_ }) -join ''; Add-Content -Path $logPath -Value ('Monitor HW: ' + $m + ' ' + $n) }"
echo.
echo DirectX Version:
echo DirectX Version: >> "%logfile%"
reg query "HKLM\SOFTWARE\Microsoft\DirectX" /v Version
reg query "HKLM\SOFTWARE\Microsoft\DirectX" /v Version >> "%logfile%"
echo.
echo. >> "%logfile%"
echo --- DISK INFORMATION ---
echo --- DISK INFORMATION --- >> "%logfile%"
echo Physical Disks:
echo Model    Size (GB)    Type
echo Model    Size (GB)    Type >> "%logfile%"
powershell -command "Get-WmiObject Win32_DiskDrive | ForEach-Object { $size = [math]::Round($_.Size / 1GB, 2); $model = $_.Model; $diskType = if($model -match 'SSD') {'SSD'} elseif($_.MediaType -match 'Fixed') {'HDD'} else {$_.MediaType}; Write-Host $model '   ' $size 'GB   ' $diskType }"
powershell -command "$logPath = '%logfile%'; Get-WmiObject Win32_DiskDrive | ForEach-Object { $size = [math]::Round($_.Size / 1GB, 2); $model = $_.Model; $diskType = if($model -match 'SSD') {'SSD'} elseif($_.MediaType -match 'Fixed') {'HDD'} else {$_.MediaType}; Add-Content -Path $logPath -Value ($model + '   ' + $size + ' GB   ' + $diskType) }"
echo.
echo Physical Disks Extended (Interface / Serial / Status / Partitions):
echo Physical Disks Extended (Interface / Serial / Status / Partitions): >> "%logfile%"
powershell -command "Get-CimInstance Win32_DiskDrive | ForEach-Object { $size=[math]::Round($_.Size/1GB,2); Write-Host ($_.Model.Trim() + ' | ' + $size + ' GB | Interface:' + $_.InterfaceType + ' | Media:' + $_.MediaType + ' | Status:' + $_.Status + ' | SN:' + $_.SerialNumber.Trim() + ' | Parts:' + $_.Partitions) }"
powershell -command "$logPath = '%logfile%'; Get-CimInstance Win32_DiskDrive | ForEach-Object { $size=[math]::Round($_.Size/1GB,2); Add-Content -Path $logPath -Value ($_.Model.Trim() + ' | ' + $size + ' GB | Interface:' + $_.InterfaceType + ' | Media:' + $_.MediaType + ' | Status:' + $_.Status + ' | SN:' + $_.SerialNumber.Trim() + ' | Parts:' + $_.Partitions) }"
echo.
echo Disk Health - BusType (NVMe/SATA/USB) + HealthStatus:
echo Disk Health - BusType (NVMe/SATA/USB) + HealthStatus: >> "%logfile%"
powershell -command "try { Get-PhysicalDisk | ForEach-Object { $sz=[math]::Round($_.Size/1GB,2); Write-Host ($_.FriendlyName + ' | Bus:' + $_.BusType + ' | Media:' + $_.MediaType + ' | Health:' + $_.HealthStatus + ' | Op:' + $_.OperationalStatus + ' | ' + $sz + ' GB') } } catch { Write-Host 'Get-PhysicalDisk not available on this OS' }"
powershell -command "$logPath = '%logfile%'; try { Get-PhysicalDisk | ForEach-Object { $sz=[math]::Round($_.Size/1GB,2); Add-Content -Path $logPath -Value ($_.FriendlyName + ' | Bus:' + $_.BusType + ' | Media:' + $_.MediaType + ' | Health:' + $_.HealthStatus + ' | Op:' + $_.OperationalStatus + ' | ' + $sz + ' GB') } } catch { Add-Content -Path $logPath -Value 'Get-PhysicalDisk not available on this OS' }"
echo.
echo Logical Drives:
echo Drive    Label    Size (GB)    Free Space (GB)    Type
echo Drive    Label    Size (GB)    Free Space (GB)    Type >> "%logfile%"
powershell -command "$physicalDisks = @{}; Get-WmiObject Win32_DiskDrive | ForEach-Object { $diskIndex = $_.Index; $diskType = if($_.Model -match 'SSD') {'SSD'} elseif($_.MediaType -match 'Fixed') {'HDD'} else {$_.MediaType}; $physicalDisks[$diskIndex] = $diskType }; Get-WmiObject Win32_LogicalDisk | ForEach-Object { $size = [math]::Round($_.Size / 1GB, 2); $free = [math]::Round($_.FreeSpace / 1GB, 2); $partitions = Get-WmiObject -Query \"ASSOCIATORS OF {Win32_LogicalDisk.DeviceID='$($_.DeviceID)'} WHERE ResultClass=Win32_DiskPartition\"; $driveType = 'Unknown'; foreach($partition in $partitions) { $drives = Get-WmiObject -Query \"ASSOCIATORS OF {Win32_DiskPartition.DeviceID='$($partition.DeviceID)'} WHERE ResultClass=Win32_DiskDrive\"; foreach($drive in $drives) { $driveType = $physicalDisks[$drive.Index] } }; Write-Host $_.DeviceID '   ' $_.VolumeName '   ' $size 'GB   ' $free 'GB   ' $driveType }"
powershell -command "$logPath = '%logfile%'; $physicalDisks = @{}; Get-WmiObject Win32_DiskDrive | ForEach-Object { $diskIndex = $_.Index; $diskType = if($_.Model -match 'SSD') {'SSD'} elseif($_.MediaType -match 'Fixed') {'HDD'} else {$_.MediaType}; $physicalDisks[$diskIndex] = $diskType }; Get-WmiObject Win32_LogicalDisk | ForEach-Object { $size = [math]::Round($_.Size / 1GB, 2); $free = [math]::Round($_.FreeSpace / 1GB, 2); $partitions = Get-WmiObject -Query \"ASSOCIATORS OF {Win32_LogicalDisk.DeviceID='$($_.DeviceID)'} WHERE ResultClass=Win32_DiskPartition\"; $driveType = 'Unknown'; foreach($partition in $partitions) { $drives = Get-WmiObject -Query \"ASSOCIATORS OF {Win32_DiskPartition.DeviceID='$($partition.DeviceID)'} WHERE ResultClass=Win32_DiskDrive\"; foreach($drive in $drives) { $driveType = $physicalDisks[$drive.Index] } }; Add-Content -Path $logPath -Value ($_.DeviceID + '   ' + $_.VolumeName + '   ' + $size + ' GB   ' + $free + ' GB   ' + $driveType) }"
echo.
echo Logical Drives Extended (FileSystem + Free %%):
echo Logical Drives Extended (FileSystem + Free %%): >> "%logfile%"
powershell -command "Get-CimInstance Win32_LogicalDisk -Filter 'DriveType=3' | ForEach-Object { $s=[math]::Round($_.Size/1GB,2); $f=[math]::Round($_.FreeSpace/1GB,2); $p=if($_.Size){[math]::Round($_.FreeSpace/$_.Size*100,1)}else{0}; Write-Host ($_.DeviceID + ' ' + $_.VolumeName + ' | FS:' + $_.FileSystem + ' | ' + $s + ' GB total ' + $f + ' GB free (' + $p + ' %% free)') }"
powershell -command "$logPath = '%logfile%'; Get-CimInstance Win32_LogicalDisk -Filter 'DriveType=3' | ForEach-Object { $s=[math]::Round($_.Size/1GB,2); $f=[math]::Round($_.FreeSpace/1GB,2); $p=if($_.Size){[math]::Round($_.FreeSpace/$_.Size*100,1)}else{0}; Add-Content -Path $logPath -Value ($_.DeviceID + ' ' + $_.VolumeName + ' | FS:' + $_.FileSystem + ' | ' + $s + ' GB total ' + $f + ' GB free (' + $p + ' %% free)') }"
echo.
echo. >> "%logfile%"
echo --- MOTHERBOARD INFORMATION ---
echo --- MOTHERBOARD INFORMATION --- >> "%logfile%"
echo Motherboard Details:
wmic baseboard get product, manufacturer, serialnumber
wmic baseboard get product, manufacturer, serialnumber >> "%logfile%"
echo.
echo BIOS Details:
wmic bios get name, version, serialnumber
wmic bios get name, version, serialnumber >> "%logfile%"
echo.
echo. >> "%logfile%"
echo --- NETWORK INFORMATION ---
echo --- NETWORK INFORMATION --- >> "%logfile%"
echo Network Adapters:
wmic nic where NetEnabled=true get Name, MACAddress
wmic nic where NetEnabled=true get Name, MACAddress >> "%logfile%"
echo.
echo IP Configuration:
ipconfig | findstr /C:"IPv4 Address" /C:"Subnet Mask" /C:"Default Gateway"
ipconfig | findstr /C:"IPv4 Address" /C:"Subnet Mask" /C:"Default Gateway" >> "%logfile%"
echo.
echo. >> "%logfile%"
echo --- HARDWARE SUMMARY ---
echo --- HARDWARE SUMMARY --- >> "%logfile%"
echo Data collection complete!
echo All details have been saved to: %logfile%
echo.
echo ===============================================
echo Type EXIT and press ENTER when you want to close
echo Or press CTRL+C and select "No" to end the batch job
echo ===============================================
echo.

:WAITLOOP
set INPUT=
set /p INPUT="Command (type EXIT to close): "
if /i "%INPUT%"=="exit" goto ENDSCRIPT
if /i "%INPUT%"=="quit" goto ENDSCRIPT
goto WAITLOOP

:ENDSCRIPT
echo Closing in 5 seconds...
timeout /t 5
echo Press any key to close the window...
pause > nul
