::[Bat To Exe Converter]
::
::YAwzoRdxOk+EWAjk
::fBw5plQjdCyDJGyX8VAjFDZbRAWPOW+GIrAP4/z0/9aKtkwhBaw2e4C7
::YAwzuBVtJxjWCl3EqQJgSA==
::ZR4luwNxJguZRRnk
::Yhs/ulQjdF+5
::cxAkpRVqdFKZSDk=
::cBs/ulQjdF+5
::ZR41oxFsdFKZSDk=
::eBoioBt6dFKZSDk=
::cRo6pxp7LAbNWATEpCI=
::egkzugNsPRvcWATEpCI=
::dAsiuh18IRvcCxnZtBJQ
::cRYluBh/LU+EWAnk
::YxY4rhs+aU+IeA==
::cxY6rQJ7JhzQF1fEqQJhZksaHWQ=
::ZQ05rAF9IBncCkqN+0xwdVs0
::ZQ05rAF9IAHYFVzEqQIdZi8abUqBMG67CLAOqPz04Obn
::eg0/rx1wNQPfEVWB+kM9LVsJDCnMCCWbSLYQ7en16vjHtkISWII=
::fBEirQZwNQPfEVWB+kM9LVsJDCnMCCWbSLYQ7en16vjHtkISWII=
::cRolqwZ3JBvQF1fEqQIzJB5VQgGQfH+1Cbl8
::dhA7uBVwLU+EWHTKwAwRZns=
::YQ03rBFzNR3SWATElA==
::dhAmsQZ3MwfNWATEphJifXs=
::ZQ0/vhVqMQ3MEVWAtB9wSA==
::Zg8zqx1/OA3MEVWAtB9wSA==
::dhA7pRFwIByZRRnk
::Zh4grVQjdCyDJGyX8VAjFDZbRAWPOW+GIrAP4/z0/9aKtkwheawLNq6V2biLIe4W+AXwepkhmH9Cnas=
::YB416Ek+ZW8=
::
::
::978f952a14a936cc963da21a135fa983

@echo off
setlocal EnableDelayedExpansion
chcp 65001 >nul 2>&1
title M.T.A. Cleaner Tool v2.0 SUPER - by Mohamed Tarek
color 0B
mode con: cols=100 lines=32 >nul 2>&1

:: ============================================================
::  M.T.A. CLEANER TOOL v2.0 SUPER
::  By Mohamed Tarek - CopyRight 2026
::  Safe + Logged + Menu-driven + Space counter
:: ============================================================

set "VER=2.0 SUPER"
set "LOGDIR=%TEMP%\MTA_Cleaner_Logs"
if not exist "%LOGDIR%" md "%LOGDIR%" >nul 2>&1
for /f "tokens=1-3 delims=/ " %%a in ('date /t') do set "DSTR=%%c-%%a-%%b"
for /f "tokens=1-2 delims=: " %%a in ('time /t') do set "TSTR=%%a-%%b"
set "TSTR=%TSTR: =0%"
set "LOG=%LOGDIR%\MTA_Clean_%DSTR%_%TSTR%.log"
set "LOG=%LOG:/=-%"
set "LOG=%LOG::=-%"
set "LOG=%LOG:,=-%"
echo [%date% %time%] M.T.A. Cleaner %VER% started > "%LOG%" 2>nul
set "START_T=%time%"

:: Get free space before (GB) - safe method, no FOR-parens crash
set "FREE_BEFORE=?"
powershell -NoProfile -Command "[math]::Round((Get-PSDrive C).Free/1GB,2)" > "%TEMP%\mta_free_b.txt" 2>nul
set /p FREE_BEFORE=<"%TEMP%\mta_free_b.txt" 2>nul
if not defined FREE_BEFORE set "FREE_BEFORE=?"
del "%TEMP%\mta_free_b.txt" >nul 2>&1

:: ============================================================
:: 0. Admin check with AUTO-ELEVATE
:: ============================================================
net session >nul 2>&1
if %errorLevel% neq 0 (
    color 0E
    echo  [!] Administrator rights required.
    echo  [*] Trying to re-launch as Administrator...
    powershell -NoProfile -Command "Start-Process -FilePath '%~f0' -Verb RunAs" >nul 2>&1
    if %errorLevel% neq 0 (
        echo  [X] Auto-elevate failed. Right-click ^> Run as Administrator.
        pause
    )
    exit /b
)

:MENU
cls
color 0B
echo ----------------------------------------------------------------------------------------------------
echo                         M.T.A. CLEANER TOOL v%VER% - by Mohamed Tarek
echo ----------------------------------------------------------------------------------------------------
echo   Free on C: %FREE_BEFORE% GB   ^|   Log: %LOG%
echo ----------------------------------------------------------------------------------------------------
echo   [1] Quick Clean        (Temp, Prefetch, Recycle, DNS, Thumbnails - SAFE, ~30 sec)
echo   [2] Deep Clean         (Everything safe + Update cache, Logs, WER, Delivery Opt.)
echo   [3] Gaming Boost       (Quick + Shader cache, Standby RAM flush, Game clients cache)
echo   [4] Privacy Clean      (Browsers, Recent, PowerShell history, RDP, OneDrive logs)
echo   [5] MAKE ALL           (Run EVERYTHING - Quick+Deep+Gaming+Privacy - Recommended)
echo   [6] Undo-safe info     (Show what is NEVER deleted)
echo   [0] Exit
echo ----------------------------------------------------------------------------------------------------
set /p "CHOICE=  Choose [1-6,0]: "
if "%CHOICE%"=="1" set "MODE=QUICK" & goto :RUN
if "%CHOICE%"=="2" set "MODE=DEEP" & goto :RUN
if "%CHOICE%"=="3" set "MODE=GAMING" & goto :RUN
if "%CHOICE%"=="4" set "MODE=PRIVACY" & goto :RUN
if "%CHOICE%"=="5" set "MODE=ALL" & goto :RUN
if "%CHOICE%"=="6" goto :SAFEINFO
if "%CHOICE%"=="0" exit /b
echo Invalid choice...
timeout /t 1 >nul
goto :MENU

:SAFEINFO
cls
echo  NEVER deleted by this tool (safety rules):
echo   - Windows folder itself, System32, your documents/desktop/downloads
echo   - Defender Quarantine (only logs, unless Deep + confirm)
echo   - Active CBS.log / active Event logs Security is OPTIONAL
echo   - No 'deltree', no format, no registry wipe, no pagefile/hibernate forced
echo   - Temp folders are EMPTIED, never removed permanently (recreated if needed)
echo.
pause
goto :MENU

:RUN
cls
echo  Mode: %MODE% ... starting. Do not close window.
echo [%date% %time%] Mode=%MODE% >> "%LOG%" 2>nul
call :STEP_QUICK
if "%MODE%"=="QUICK" goto :DONE
if "%MODE%"=="PRIVACY" goto :DO_PRIVACY_ONLY
call :STEP_PRIVACY
if "%MODE%"=="GAMING" call :STEP_GAMING_CACHE
if "%MODE%"=="GAMING" goto :DONE
REM DEEP and ALL = run everything (Deep + UpdateFix + Gaming cache)
call :STEP_DEEP
call :STEP_UPDATEFIX_SAFE
call :STEP_GAMING_CACHE
goto :DONE

:DO_PRIVACY_ONLY
call :STEP_PRIVACY
goto :DONE

:: ================= QUICK (always safe) =================
:STEP_QUICK
call :HDR "Quick Clean - Temp + Prefetch + Recycle + DNS + Thumbnails"
:: 1. Flush DNS
ipconfig /flushdns >> "%LOG%" 2>&1
:: 2. Empty Recycle Bin (all drives, silent)
powershell -NoProfile -Command "Clear-RecycleBin -Force -ErrorAction SilentlyContinue" >> "%LOG%" 2>&1
:: 3. Windows Temp contents (keep folder, keep permissions)
call :CLEAN_CONTENTS "C:\Windows\Temp"
:: 4. User Temp (current user)
call :CLEAN_CONTENTS "%TEMP%"
if /i not "%TEMP%"=="%USERPROFILE%\AppData\Local\Temp" call :CLEAN_CONTENTS "%USERPROFILE%\AppData\Local\Temp"
:: 5. All users Temp (safe loop, contents only - single-line CALL avoids FOR-parens crash)
for /D %%p in (C:\Users\*) do call :CLEAN_ONE_USER_TEMP "%%p"
:: 6. Prefetch contents only (keep folder - deleting folder hurts boot)
call :CLEAN_CONTENTS "%windir%\Prefetch"
:: 7. Thumbnail cache
call :DEL_SAFE "%LOCALAPPDATA%\Microsoft\Windows\Explorer\thumbcache_*.db"
:: 8. Mini dumps + old .tmp/.etl/.dmp in Temp
del /q /f "%WINDIR%\Temp\*.etl" "%WINDIR%\Temp\*.dmp" "%WINDIR%\Temp\*.tmp" >> "%LOG%" 2>&1
del /q /f "%TEMP%\*.tmp" "%TEMP%\*.etl" "%TEMP%\*.dmp" >> "%LOG%" 2>&1
:: 9. Internet temp + cookies legacy (safe, if exist)
call :DEL_SAFE "%LOCALAPPDATA%\Microsoft\Windows\INetCache\*"
call :DEL_SAFE "%LOCALAPPDATA%\Microsoft\Windows\INetCookies\*"
goto :eof

:: ================= PRIVACY =================
:STEP_PRIVACY
call :HDR "Privacy - Browsers + Recent + RDP + PowerShell + OneDrive"
:: Browsers (only Cache, not passwords/cookies/bookmarks)
call :CLEAN_CONTENTS "%LOCALAPPDATA%\Google\Chrome\User Data\Default\Cache"
call :CLEAN_CONTENTS "%LOCALAPPDATA%\Google\Chrome\User Data\Default\Code Cache"
call :CLEAN_CONTENTS "%LOCALAPPDATA%\Microsoft\Edge\User Data\Default\Cache"
call :CLEAN_CONTENTS "%LOCALAPPDATA%\Microsoft\Edge\User Data\Default\Code Cache"
call :CLEAN_CONTENTS "%LOCALAPPDATA%\BraveSoftware\Brave-Browser\User Data\Default\Cache"
call :CLEAN_CONTENTS "%LOCALAPPDATA%\Opera Software\Opera Stable\Cache"
:: Firefox: only cache2 entries, keep profiles intact (never wipe Profiles root)
if not exist "%LOCALAPPDATA%\Mozilla\Firefox\Profiles" goto :SKIP_FF
for /D %%f in ("%LOCALAPPDATA%\Mozilla\Firefox\Profiles\*") do call :CLEAN_ONE_FF "%%f"
:SKIP_FF
:: Recent / Jump lists (list only, not files)
del /q /f "%APPDATA%\Microsoft\Windows\Recent\*" >> "%LOG%" 2>&1
del /q /f "%APPDATA%\Microsoft\Windows\Recent\AutomaticDestinations\*" >> "%LOG%" 2>&1
del /q /f "%APPDATA%\Microsoft\Windows\Recent\CustomDestinations\*" >> "%LOG%" 2>&1
:: RDP cache
call :CLEAN_CONTENTS "%USERPROFILE%\AppData\Local\Microsoft\Terminal Server Client\Cache"
:: PowerShell history (fixed missing quote bug)
call :DEL_SAFE "%APPDATA%\Microsoft\Windows\PowerShell\PSReadLine\ConsoleHost_history.txt"
call :DEL_SAFE "%USERPROFILE%\AppData\Local\Microsoft\Windows\PowerShell\PSReadLine\ConsoleHost_history.txt"
:: OneDrive logs/temp only
call :CLEAN_CONTENTS "%LOCALAPPDATA%\Microsoft\OneDrive\logs"
:: Teams / Discord / Steam web cache only (keeps login)
call :CLEAN_CONTENTS "%APPDATA%\discord\Cache"
call :CLEAN_CONTENTS "%APPDATA%\discord\Code Cache"
call :CLEAN_CONTENTS "%LOCALAPPDATA%\Microsoft\Teams\Cache"
call :CLEAN_CONTENTS "%ProgramFiles(x86)%\Steam\appcache\httpcache"
goto :eof

:: ================= DEEP (system logs/caches) =================
:STEP_DEEP
call :HDR "Deep System Clean - Logs + WER + Delivery + Font + Java + CBS"
:: WER queues
call :CLEAN_CONTENTS "%LOCALAPPDATA%\Microsoft\Windows\WER\ReportQueue"
call :CLEAN_CONTENTS "%ProgramData%\Microsoft\Windows\WER\ReportQueue"
call :CLEAN_CONTENTS "%ProgramData%\Microsoft\Windows\WER\ReportArchive"
call :CLEAN_CONTENTS "%ProgramData%\Microsoft\Windows\WER\Temp"
:: Diagnostic data
call :CLEAN_CONTENTS "%ProgramData%\Microsoft\Diagnosis"
:: CBS logs: keep active CBS.log, delete .cab/.old
del /q /f "C:\Windows\Logs\CBS\*.cab" "C:\Windows\Logs\CBS\*.old" "C:\Windows\Logs\CBS\CbsPersist*.log" >> "%LOG%" 2>&1
:: Windows Update logs + System LogFiles (keep folder structure)
call :CLEAN_CONTENTS "%WINDIR%\Logs\WindowsUpdate"
call :CLEAN_CONTENTS "%WINDIR%\System32\LogFiles"
call :CLEAN_CONTENTS "%WINDIR%\Logs\DPX"
:: Delivery Optimization cache (service-safe)
net stop DoSvc /y >> "%LOG%" 2>&1
call :CLEAN_CONTENTS "%WINDIR%\ServiceProfiles\NetworkService\AppData\Local\DeliveryOptimization\Cache"
net start DoSvc >> "%LOG%" 2>&1
:: Font cache (service-safe)
net stop FontCache /y >> "%LOG%" 2>&1
call :DEL_SAFE "%WINDIR%\ServiceProfiles\LocalService\AppData\Local\FontCache\*"
net start FontCache >> "%LOG%" 2>&1
:: Java cache
call :CLEAN_CONTENTS "%USERPROFILE%\AppData\LocalLow\Sun\Java\Deployment\cache"
call :CLEAN_CONTENTS "%USERPROFILE%\AppData\LocalLow\Oracle\Java\Deployment\cache"
:: Defender: LOGS ONLY (quarantine kept for safety). Ask once for quarantine.
call :DEL_SAFE "%ProgramData%\Microsoft\Windows Defender\Support\*.log"
call :DEL_SAFE "%ProgramData%\Microsoft\Windows Defender\Support\*.log.old"
call :DEL_SAFE "%ProgramData%\Microsoft\Windows Defender\Scans\History\*"
:: Event logs: Application/System/Setup only. Security skipped (needs special audit).
wevtutil cl Application >> "%LOG%" 2>&1
wevtutil cl System >> "%LOG%" 2>&1
wevtutil cl Setup >> "%LOG%" 2>&1
:: BITS queue
bitsadmin /reset /allusers >> "%LOG%" 2>&1
:: Windows.old (only if exists, via safe rd + DISM marker)
if exist "C:\Windows.old" (
    echo  [*] Removing C:\Windows.old ...
    takeown /F "C:\Windows.old" /R /D Y >> "%LOG%" 2>&1
    icacls "C:\Windows.old" /grant administrators:F /T >> "%LOG%" 2>&1
    rd /s /q "C:\Windows.old" >> "%LOG%" 2>&1
)
:: Temp installer leftovers
del /q /f "%TEMP%\*.exe" "%TEMP%\*.msi" >> "%LOG%" 2>&1
goto :eof

:: ================= UPDATE FIX (service-safe) =================
:STEP_UPDATEFIX
call :HDR "Windows Update Fix + DISM Component Cleanup"
echo  [*] Stopping update services...
net stop wuauserv >> "%LOG%" 2>&1
net stop cryptSvc >> "%LOG%" 2>&1
net stop bits >> "%LOG%" 2>&1
net stop msiserver >> "%LOG%" 2>&1
call :CLEAN_CONTENTS "%windir%\SoftwareDistribution\Download"
call :CLEAN_CONTENTS "%windir%\SoftwareDistribution\DataStore\Logs"
del /q /f "%WINDIR%\Logs\WindowsUpdate\*" >> "%LOG%" 2>&1
echo  [*] Restarting services...
net start wuauserv >> "%LOG%" 2>&1
net start cryptSvc >> "%LOG%" 2>&1
net start bits >> "%LOG%" 2>&1
net start msiserver >> "%LOG%" 2>&1
echo  [*] DISM component cleanup (may take minutes)...
DISM.exe /Online /Cleanup-Image /StartComponentCleanup /ResetBase >> "%LOG%" 2>&1
goto :eof

:STEP_UPDATEFIX_SAFE
call :STEP_UPDATEFIX
goto :eof

:: ================= GAMING CACHE + RAM =================
:STEP_GAMING_CACHE
call :HDR "Gaming Boost - Shader cache + Standby RAM flush"
:: DirectX / NVIDIA / AMD shader caches (regenerates automatically)
call :CLEAN_CONTENTS "%LOCALAPPDATA%\D3DSCache"
call :CLEAN_CONTENTS "%LOCALAPPDATA%\NVIDIA\DXCache"
call :CLEAN_CONTENTS "%LOCALAPPDATA%\NVIDIA\GLCache"
call :CLEAN_CONTENTS "%APPDATA%\NVIDIA\ComputeCache"
call :CLEAN_CONTENTS "%LOCALAPPDATA%\AMD\DxCache"
call :CLEAN_CONTENTS "%LOCALAPPDATA%\AMD\DxcCache"
:: Steam shader + depot cache (safe)
call :CLEAN_CONTENTS "%ProgramFiles(x86)%\Steam\shadercache"
call :CLEAN_CONTENTS "%ProgramFiles(x86)%\Steam\depotcache"
:: Epic launcher webcache
call :CLEAN_CONTENTS "%LOCALAPPDATA%\EpicGamesLauncher\Saved\webcache"
:: Flush standby list via PowerShell (no external exe needed)
powershell -NoProfile -Command "$m='[DllImport(\"psapi.dll\")]public static extern bool EmptyWorkingSet(IntPtr h);'; $t=Add-Type -MemberDefinition $m -Name P -Namespace W -PassThru; foreach($p in Get-Process){try{$t::EmptyWorkingSet($p.Handle)|Out-Null}catch{}}; [GC]::Collect()" >> "%LOG%" 2>&1
:: Flush DNS again for lower ping variance
ipconfig /flushdns >> "%LOG%" 2>&1
goto :eof

:DONE
:: Final free space + summary - safe method, no FOR-parens crash
set "FREE_AFTER=?"
powershell -NoProfile -Command "[math]::Round((Get-PSDrive C).Free/1GB,2)" > "%TEMP%\mta_free_a.txt" 2>nul
set /p FREE_AFTER=<"%TEMP%\mta_free_a.txt" 2>nul
if not defined FREE_AFTER set "FREE_AFTER=?"
del "%TEMP%\mta_free_a.txt" >nul 2>&1
cls
color 0A
echo ====================================================================
echo    SYSTEM CLEANUP COMPLETED - M.T.A. Cleaner v%VER%
echo ====================================================================
echo    Mode         : %MODE%
echo    C: before    : %FREE_BEFORE% GB free
echo    C: after     : %FREE_AFTER% GB free
echo    Log file     : %LOG%
echo ====================================================================
echo    Safe notes:
echo     - Temp folders EMPTIED, not deleted. Permissions kept.
echo     - Defender Quarantine KEPT. Browser passwords KEPT.
echo     - Reboot recommended if you did Deep / Update Fix.
echo ====================================================================
echo [%date% %time%] Done. Before=%FREE_BEFORE%GB After=%FREE_AFTER%GB >> "%LOG%" 2>&1
echo.
echo          Process Completed - @M.T.A.
echo.
pause
goto :MENU

:: ============================================================
:: SUBROUTINES (fixes old bugs: missing label, deltree, hardcoded HP)
:: ============================================================

:HDR
echo.
echo  ---- %~1 ----
echo [%date% %time%] %~1 >> "%LOG%" 2>&1
goto :eof

:: Safe file delete: call :DEL_SAFE "pattern"
:DEL_SAFE
if "%~1"=="" goto :eof
del /f /q "%~1" >> "%LOG%" 2>&1
goto :eof

:: Safe clean folder CONTENTS, keep root folder + permissions
:: call :CLEAN_CONTENTS "C:\path\to\folder"
:CLEAN_CONTENTS
if "%~1"=="" goto :eof
if not exist "%~1" goto :eof
echo  [clean] %~1
echo [%date% %time%] clean %~1 >> "%LOG%" 2>&1
del /f /q /s "%~1\*" >> "%LOG%" 2>&1
for /d %%d in ("%~1\*") do rd /s /q "%%d" >> "%LOG%" 2>&1
goto :eof

:: Helper: clean one user's Temp (called single-line from FOR, safe)
:CLEAN_ONE_USER_TEMP
if "%~1"=="" goto :eof
if not exist "%~1\AppData\Local\Temp" goto :eof
call :CLEAN_CONTENTS "%~1\AppData\Local\Temp"
goto :eof

:: Helper: clean one Firefox profile's cache2 only (called single-line from FOR, safe)
:CLEAN_ONE_FF
if "%~1"=="" goto :eof
if not exist "%~1\cache2" goto :eof
call :CLEAN_CONTENTS "%~1\cache2"
goto :eof
