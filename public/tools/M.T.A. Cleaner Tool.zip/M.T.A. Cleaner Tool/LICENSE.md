# M.T.A. Cleaner Tool – License Agreement

**Copyright © 2026 Mohamed Tarek. All rights reserved.**

This software (`M.T.A.cleaner tool.bat`, including any compiled EXE built from it) is provided free of charge for **personal, non-commercial use** only. By downloading, copying, or using this software, you agree to the following terms:

---

## ✅ Permitted Use

- You may use this software **for personal purposes only** on your own devices.
- You may review and study the code.
- You may modify the script **for personal use only** on your own devices.
- You may keep backup copies for personal use.

---

## ❌ Restrictions

- **Commercial use**, redistribution, or integration into other products or services is **strictly prohibited** without prior written permission from the author.
- You **may not sell**, license, sublicense, or otherwise commercially exploit this software.
- You **may not publicly share** modified versions without written authorization.
- You **may not remove** or obscure any copyright, trademark, or attribution notices (including the in-script header `M.T.A. Cleaner Tool by Mohamed Tarek`).

---

## ⚠️ Disclaimer

This software is provided **"as is"**, without warranty of any kind, express or implied.
It permanently deletes temporary files, caches, and logs. Use at your own risk.
The author assumes no responsibility for damage to systems, data loss, or any other impact resulting from the use of this software. Running on a test system / backup first is recommended. Administrator privileges are required.

---

## 📬 Contact for Commercial Licensing

For business inquiries or to request permission for redistribution or commercial use, please contact:

**Mohamed Tarek**
Email: [medoteto2252003@gmail.com]
Website: [https://website-mohamed.vercel.app/]
