# M.T.A. Cleaner — Comprehensive System Cleaning Tool
**Developer:** Mohamed Tarek
**Version:** 2.0 SUPER (2026)
**Format:** BAT (Bat-To-Exe compatible)

## 📌 Overview
**M.T.A. Cleaner** is a safe, menu-driven, all-in-one Windows cleanup and maintenance tool.
It empties temp files, clears system and app caches, deletes outdated logs, resets stuck Windows Update cache (service-safe), flushes shader caches for gaming, and shows freed space before/after — with full logging.

> Safety first: folders are **emptied, never removed**. Permissions are kept. Passwords, documents, and Defender Quarantine are **never touched**.

## 🚀 Menu Options

| Choice | Mode | What it does | Time |
|--------|------|--------------|------|
| `1` | Quick Clean | Windows Temp, User Temp (all users), Prefetch contents, Recycle Bin, DNS flush, Thumbnail cache, INetCache | ~30 sec, SAFE |
| `2` | Deep Clean | Quick + Privacy + Deep system + Update Fix + Gaming cache (same as MAKE ALL) | several minutes |
| `3` | Gaming Boost | Quick + Privacy + DirectX/NVIDIA/AMD shader cache, Steam/Epic webcache, RAM working-set flush, DNS flush | ~1-2 min |
| `4` | Privacy Clean | Browser cache only (Chrome/Edge/Brave/Opera/Firefox `cache2`), Recent/Jump lists, RDP cache, PowerShell history, OneDrive logs, Discord/Teams/Steam webcache | ~1 min |
| `5` | MAKE ALL | **Run EVERYTHING** — Quick + Privacy + Deep + Update Fix + Gaming. Recommended | several minutes |
| `6` | Safe-info | Shows what is NEVER deleted | — |
| `0` | Exit | — | — |

## 🔹 What Gets Cleaned

### Quick
- `C:\Windows\Temp\*`, `%TEMP%\*`, all `C:\Users\*\AppData\Local\Temp\*` (contents only)
- `%windir%\Prefetch\*` (contents only, folder kept for boot perf)
- Recycle Bin (`Clear-RecycleBin -Force`), `ipconfig /flushdns`
- `thumbcache_*.db`, `*.etl/*.dmp/*.tmp` in Temp folders

### Privacy (cache only, logins/passwords kept)
- Chrome / Edge / Brave / Opera `Cache` + `Code Cache`
- Firefox `cache2` only (profiles never wiped)
- `Recent`, `AutomaticDestinations`, `CustomDestinations` (lists only)
- Terminal Server Client Cache, PSReadLine `ConsoleHost_history.txt`, OneDrive `logs`
- Discord / Teams / Steam `httpcache` (webcache only)

### Deep System
- WER `ReportQueue`, `ReportArchive`, `Temp` (user + system)
- `%ProgramData%\Microsoft\Diagnosis\*`
- CBS: `*.cab`, `*.old`, `CbsPersist*.log` only (active `CBS.log` kept)
- `Logs\WindowsUpdate`, `System32\LogFiles`, `Logs\DPX`
- Delivery Optimization cache (DoSvc stopped/started safely)
- FontCache (FontCache service stopped/started safely)
- Java Sun/Oracle `Deployment\cache`
- Defender **logs only**: `Support\*.log`, `Scans\History` (Quarantine KEPT)
- Event Logs: Application, System, Setup (Security skipped)
- BITS queue (`bitsadmin /reset`), `C:\Windows.old` (takeown + icacls + rd, only if exists)
- Temp installer leftovers `*.exe/*.msi` in `%TEMP%`

### Windows Update Fix (part of Deep / MAKE ALL, service-safe)
- Stops `wuauserv`, `cryptSvc`, `bits`, `msiserver`
- Clears `SoftwareDistribution\Download`, `DataStore\Logs`, `Logs\WindowsUpdate`
- Restarts services
- `DISM /Online /Cleanup-Image /StartComponentCleanup /ResetBase`

### Gaming Boost
- `D3DSCache`, NVIDIA `DXCache`/`GLCache`/`ComputeCache`, AMD `DxCache`/`DxcCache`
- Steam `shadercache`/`depotcache`, Epic `webcache`
- RAM working-set flush via PowerShell (no external EXE needed) + DNS flush

## 🛡️ What Is NEVER Deleted
- Windows / System32 itself, Documents / Desktop / Downloads
- Defender Quarantine, browser passwords/cookies/bookmarks, Firefox profiles
- Active `CBS.log`, Security event log
- No `deltree`, no format, no registry wipe, no forced hibernate/pagefile change

## ⚙️ How to Run
1. Double-click `M.T.A.cleaner tool.bat` — it **auto-elevates** to Administrator (UAC prompt).
2. If auto-elevate fails: **Right-click → Run as Administrator**.
3. Choose `1-5`, wait for `SYSTEM CLEANUP COMPLETED`, check freed GB + log path.
4. Reboot recommended after Deep / MAKE ALL.

Log files: `%TEMP%\MTA_Cleaner_Logs\MTA_Clean_*.log`

## ⚠️ Notes
- Tool **permanently deletes** caches/logs/temp files (regenerable). Run on test system first if unsure.
- Requires **Administrator privileges**.
- DISM step needs internet-optional but takes minutes — do not close the window.
- Bat-To-Exe header at top of `.bat` is preserved for EXE conversion.

## 📄 License
See `LICENSE.md` — Copyright © 2026 Mohamed Tarek. Free for personal, non-commercial use with credit. See license for redistribution/commercial terms.
