@echo off
setlocal enabledelayedexpansion

:: --- Go to script directory
cd /d "%~dp0"

:: --- Check yt-dlp presence
if not exist "yt-dlp.exe" (
  echo [ERROR] yt-dlp.exe not found in "%~dp0"
  echo Download yt-dlp from: https://github.com/yt-dlp/yt-dlp/releases
  pause
  exit /b 1
)

:: --- Check ffmpeg presence (optional but recommended)
where /q ffmpeg
if errorlevel 1 (
  echo [WARN] ffmpeg.exe not found in PATH. Merging/thumbnail embedding may fail.
)

:: --- Get URL: arg1 or prompt
set "URL=%~1"
if "%URL%"=="" (
  set /p URL=Paste video/playlist URL: 
)
if "%URL%"=="" (
  echo [ERROR] No URL provided.
  pause
  exit /b 1
)

:: --- Output directory
set "OUTDIR=%~dp0downloads"
if not exist "%OUTDIR%" mkdir "%OUTDIR%"

:: --- Optional: try cookies from installed browsers (for private/playlists)
set "COOKIES_OPT="
for %%B in (chrome edge firefox) do (
  yt-dlp.exe --cookies-from-browser %%B --print "ok" >nul 2>&1
  if not errorlevel 1 (
    set "COOKIES_OPT=--cookies-from-browser %%B"
    goto :download
  )
)

:download
:: --- Download: prefer 720p AVC + M4A => MP4, fallback best<=720 single file
yt-dlp.exe ^
  -f "bv*[height<=720][vcodec^=avc1]+ba[ext=m4a]/b[height<=720][ext=mp4]" ^
  --merge-output-format mp4 ^
  --embed-metadata --embed-thumbnail ^
  --ppa "ffmpeg:-movflags +faststart" ^
  --no-mtime ^
  --trim-filenames 240 ^
  -ciw --no-overwrites --sleep-requests 2 --retries 10 --fragment-retries 10 ^
  --concurrent-fragments 5 ^
  --download-archive "%OUTDIR%\downloaded.txt" ^
  -P "%OUTDIR%" ^
  -o "%%(playlist_title,channel)s/%%(playlist_index&%%(playlist_index)03d - )s%%(title)s.%%(ext)s" ^
  %COOKIES_OPT% ^
  "%URL%"

if errorlevel 1 (
  echo [FAIL] Download failed. See messages above.
) else (
  echo [OK] Done.
)
pause
