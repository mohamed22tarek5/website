@echo off
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0MTA-Downloader-GUI.ps1"
