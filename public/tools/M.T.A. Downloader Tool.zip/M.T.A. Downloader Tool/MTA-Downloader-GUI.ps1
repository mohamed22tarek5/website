#Requires -Version 5.1
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

function New-Form {
  $form                   = New-Object System.Windows.Forms.Form
  $form.Text              = "M.T.A. Downloader GUI"
  $form.Size              = New-Object System.Drawing.Size(860, 640)
  $form.StartPosition     = 'CenterScreen'
  $form.TopMost           = $false

  $font                   = New-Object System.Drawing.Font('Segoe UI', 9)
  $form.Font              = $font

  # === Controls ===
  $lblUrl                 = New-Object System.Windows.Forms.Label
  $lblUrl.Text            = 'Video / Playlist URL:'
  $lblUrl.Location        = '14,15'
  $lblUrl.AutoSize        = $true

  $txtUrl                 = New-Object System.Windows.Forms.TextBox
  $txtUrl.Location        = '14,35'
  $txtUrl.Width           = 650
  $txtUrl.AllowDrop       = $true

  $btnPaste               = New-Object System.Windows.Forms.Button
  $btnPaste.Text          = 'Paste'
  $btnPaste.Location      = '672,33'
  $btnPaste.Width         = 70

  $btnTestUrl             = New-Object System.Windows.Forms.Button
  $btnTestUrl.Text        = 'Info'
  $btnTestUrl.Location    = '748,33'
  $btnTestUrl.Width       = 70
  $btnTestUrl.ToolTipText = 'Probe URL with yt-dlp --print title'

  $lblOutDir              = New-Object System.Windows.Forms.Label
  $lblOutDir.Text         = 'Output folder:'
  $lblOutDir.Location     = '14,70'
  $lblOutDir.AutoSize     = $true

  $txtOutDir              = New-Object System.Windows.Forms.TextBox
  $txtOutDir.Location     = '14,90'
  $txtOutDir.Width        = 650
  $defaultOut             = Join-Path $PSScriptRoot 'downloads'
  if (-not (Test-Path $defaultOut)) { New-Item -ItemType Directory -Force -Path $defaultOut | Out-Null }
  $txtOutDir.Text         = $defaultOut

  $btnBrowseOut           = New-Object System.Windows.Forms.Button
  $btnBrowseOut.Text      = 'Browse...'
  $btnBrowseOut.Location  = '672,88'
  $btnBrowseOut.Width     = 70

  $btnOpenOut             = New-Object System.Windows.Forms.Button
  $btnOpenOut.Text        = 'Open'
  $btnOpenOut.Location    = '748,88'
  $btnOpenOut.Width       = 70

  $grpOptions             = New-Object System.Windows.Forms.GroupBox
  $grpOptions.Text        = 'Options'
  $grpOptions.Location    = '14,130'
  $grpOptions.Size        = New-Object System.Drawing.Size(804, 120)

  $lblQuality             = New-Object System.Windows.Forms.Label
  $lblQuality.Text        = 'Quality preset:'
  $lblQuality.Location    = '14,24'
  $lblQuality.AutoSize    = $true

  $cmbQuality             = New-Object System.Windows.Forms.ComboBox
  $cmbQuality.Location    = '110,20'
  $cmbQuality.Width       = 270
  $cmbQuality.DropDownStyle = 'DropDownList'
  $null = $cmbQuality.Items.Add('≤720p AVC + M4A → MP4 (recommended)')
  $null = $cmbQuality.Items.Add('Best MP4 (any height ≤1080p)')
  $cmbQuality.SelectedIndex = 0

  $chkThumb               = New-Object System.Windows.Forms.CheckBox
  $chkThumb.Text          = 'Embed thumbnail & metadata'
  $chkThumb.Location      = '400,22'
  $chkThumb.Checked       = $true
  $chkThumb.AutoSize      = $true

  $chkNoMtime             = New-Object System.Windows.Forms.CheckBox
  $chkNoMtime.Text        = 'Keep local file time (no mtime)'
  $chkNoMtime.Location    = '610,22'
  $chkNoMtime.Checked     = $true
  $chkNoMtime.AutoSize    = $true

  $lblFileName            = New-Object System.Windows.Forms.Label
  $lblFileName.Text       = 'Filename template:'
  $lblFileName.Location   = '14,54'
  $lblFileName.AutoSize   = $true

  $txtTemplate            = New-Object System.Windows.Forms.TextBox
  $txtTemplate.Location   = '140,50'
  $txtTemplate.Width      = 640
  $txtTemplate.Text       = '%(playlist_title,channel)s/%(playlist_index&%(playlist_index)03d - )s%(title)s.%(ext)s'

  $chkArchive             = New-Object System.Windows.Forms.CheckBox
  $chkArchive.Text        = 'Skip previously downloaded (archive)'
  $chkArchive.Location    = '14,80'
  $chkArchive.Checked     = $true
  $chkArchive.AutoSize    = $true

  $chkRestrict            = New-Object System.Windows.Forms.CheckBox
  $chkRestrict.Text       = 'Restrict filenames (ASCII-safe)'
  $chkRestrict.Location   = '300,80'
  $chkRestrict.Checked    = $false
  $chkRestrict.AutoSize   = $true

  $chkFragments           = New-Object System.Windows.Forms.CheckBox
  $chkFragments.Text      = 'Faster segmented streams (concurrent fragments)'
  $chkFragments.Location  = '520,80'
  $chkFragments.Checked   = $true
  $chkFragments.AutoSize  = $true

  $grpCookies             = New-Object System.Windows.Forms.GroupBox
  $grpCookies.Text        = 'Authentication / Cookies'
  $grpCookies.Location    = '14,260'
  $grpCookies.Size        = New-Object System.Drawing.Size(804, 80)

  $chkUseCookies          = New-Object System.Windows.Forms.CheckBox
  $chkUseCookies.Text     = 'Use cookies from browser:'
  $chkUseCookies.Location = '14,30'
  $chkUseCookies.Checked  = $true
  $chkUseCookies.AutoSize = $true

  $cmbBrowser             = New-Object System.Windows.Forms.ComboBox
  $cmbBrowser.Location    = '190,26'
  $cmbBrowser.Width       = 130
  $cmbBrowser.DropDownStyle = 'DropDownList'
  $null = $cmbBrowser.Items.Add('auto')
  $null = $cmbBrowser.Items.Add('chrome')
  $null = $cmbBrowser.Items.Add('edge')
  $null = $cmbBrowser.Items.Add('firefox')
  $cmbBrowser.SelectedIndex = 0

  $btnTestCookies         = New-Object System.Windows.Forms.Button
  $btnTestCookies.Text    = 'Test cookies'
  $btnTestCookies.Location= '340,24'
  $btnTestCookies.Width   = 110

  $lblYtdlp               = New-Object System.Windows.Forms.Label
  $lblYtdlp.Text          = 'yt-dlp.exe:'
  $lblYtdlp.Location      = '480,28'
  $lblYtdlp.AutoSize      = $true

  $lblYtdlpPath           = New-Object System.Windows.Forms.Label
  $lblYtdlpPath.Location  = '540,28'
  $lblYtdlpPath.AutoSize  = $true

  $grpRun                 = New-Object System.Windows.Forms.GroupBox
  $grpRun.Text            = 'Run'
  $grpRun.Location        = '14,350'
  $grpRun.Size            = New-Object System.Drawing.Size(804, 60)

  $btnStart               = New-Object System.Windows.Forms.Button
  $btnStart.Text          = 'Start'
  $btnStart.Location      = '14,22'
  $btnStart.Width         = 120

  $btnCancel              = New-Object System.Windows.Forms.Button
  $btnCancel.Text         = 'Cancel'
  $btnCancel.Location     = '142,22'
  $btnCancel.Width        = 120
  $btnCancel.Enabled      = $false

  $lblStatus              = New-Object System.Windows.Forms.Label
  $lblStatus.Text         = 'Ready.'
  $lblStatus.Location     = '280,26'
  $lblStatus.AutoSize     = $true

  $txtLog                 = New-Object System.Windows.Forms.TextBox
  $txtLog.Location        = '14,420'
  $txtLog.Multiline       = $true
  $txtLog.ScrollBars      = 'Vertical'
  $txtLog.WordWrap        = $false
  $txtLog.ReadOnly        = $true
  $txtLog.Size            = New-Object System.Drawing.Size(804, 160)

  # === Helpers ===
  $process = $null
  function Append-Log([string]$msg) {
    $ts = (Get-Date).ToString('HH:mm:ss')
    $txtLog.AppendText("[$ts] $msg`r`n")
  }

  function Ensure-Binaries {
    $yt = Join-Path $PSScriptRoot 'yt-dlp.exe'
    $lblYtdlpPath.Text = if (Test-Path $yt) { $yt } else { 'NOT FOUND' }

    if (-not (Test-Path $yt)) {
      [System.Windows.Forms.MessageBox]::Show('yt-dlp.exe not found in script folder. Download from: https://github.com/yt-dlp/yt-dlp/releases', 'Missing yt-dlp', 'OK', 'Warning') | Out-Null
      return $false
    }

    # ffmpeg check (optional)
    $ffmpeg = Get-Command ffmpeg -ErrorAction SilentlyContinue
    if (-not $ffmpeg) { Append-Log 'WARN: ffmpeg.exe not found in PATH. Muxing/thumbnail embedding may fail.' }
    return $true
  }

  function Build-Args {
    param([string]$url,[string]$outDir)

    $fmt = if ($cmbQuality.SelectedIndex -eq 0) {
      'bv*[height<=720][vcodec^=avc1]+ba[ext=m4a]/b[height<=720][ext=mp4]'
    } else {
      'b[ext=mp4][height<=1080]/b[ext=mp4]'
    }

    $args = @(
      '-f', $fmt,
      '--merge-output-format','mp4',
      '-ciw','--no-overwrites','--sleep-requests','2','--retries','10','--fragment-retries','10',
      '-P', $outDir,
      '-o', $txtTemplate.Text
    )

    if ($chkThumb.Checked) {
      $args += @('--embed-metadata','--embed-thumbnail','--ppa','ffmpeg:-movflags +faststart')
    }
    if ($chkNoMtime.Checked) { $args += '--no-mtime' }
    if (-not $chkRestrict.Checked) { $args += @('--trim-filenames','240') } else { $args += '--restrict-filenames' }
    if ($chkFragments.Checked) { $args += @('--concurrent-fragments','5') }
    if ($chkArchive.Checked) {
      $archive = Join-Path $outDir 'downloaded.txt'
      $args += @('--download-archive', $archive)
    }

    if ($chkUseCookies.Checked) {
      $browser = $cmbBrowser.SelectedItem.ToString()
      if ($browser -eq 'auto') {
        foreach ($b in 'chrome','edge','firefox') {
          $p = Start-Process -FilePath (Join-Path $PSScriptRoot 'yt-dlp.exe') -ArgumentList "--cookies-from-browser $b --print ok" -WindowStyle Hidden -Wait -PassThru
          if ($p.ExitCode -eq 0) { $args += @('--cookies-from-browser', $b); break }
        }
      } else {
        $args += @('--cookies-from-browser', $browser)
      }
    }

    $args += $url
    return ,$args
  }

  function Start-Download {
    if (-not (Ensure-Binaries)) { return }

    $url = $txtUrl.Text.Trim()
    if (-not $url) { [System.Windows.Forms.MessageBox]::Show('Please paste a URL.','Missing URL','OK','Information') | Out-Null; return }

    $outDir = $txtOutDir.Text.Trim()
    if (-not (Test-Path $outDir)) { New-Item -ItemType Directory -Force -Path $outDir | Out-Null }

    $args = Build-Args -url $url -outDir $outDir
    Append-Log ("yt-dlp.exe " + ($args -join ' '))

    $psi = New-Object System.Diagnostics.ProcessStartInfo
    $psi.FileName = (Join-Path $PSScriptRoot 'yt-dlp.exe')
    $psi.Arguments = [string]::Join(' ', ($args | ForEach-Object { if ($_ -match '\s') { '"' + $_ + '"' } else { $_ } }))
    $psi.RedirectStandardOutput = $true
    $psi.RedirectStandardError  = $true
    $psi.UseShellExecute        = $false
    $psi.CreateNoWindow         = $true

    $process = New-Object System.Diagnostics.Process
    $process.StartInfo = $psi

    $null = $process.Start()
    $btnStart.Enabled  = $false
    $btnCancel.Enabled = $true
    $lblStatus.Text    = 'Downloading...'

    Register-ObjectEvent -InputObject $process -EventName 'OutputDataReceived' -Action { if ($EventArgs.Data) { $ExecutionContext.InvokeCommand.ExpandString("$($EventArgs.Data)") | ForEach-Object { $form.Invoke([Action]{ Append-Log $_ }) } } } | Out-Null
    Register-ObjectEvent -InputObject $process -EventName 'ErrorDataReceived'  -Action { if ($EventArgs.Data) { $ExecutionContext.InvokeCommand.ExpandString("$($EventArgs.Data)") | ForEach-Object { $form.Invoke([Action]{ Append-Log $_ }) } } } | Out-Null

    $process.BeginOutputReadLine()
    $process.BeginErrorReadLine()

    Start-Job -ScriptBlock {
      param($pid)
      $p = Get-Process -Id $pid -ErrorAction SilentlyContinue
      if ($p) { $p.WaitForExit() }
      return $p.ExitCode
    } -ArgumentList $process.Id | Out-Null

    $timer = New-Object System.Windows.Forms.Timer
    $timer.Interval = 300
    $timer.Add_Tick({
      $p = Get-Process -Id $process.Id -ErrorAction SilentlyContinue
      if (-not $p) {
        $timer.Stop()
        $exit = $process.ExitCode
        $form.Invoke([Action]{
          $btnStart.Enabled  = $true
          $btnCancel.Enabled = $false
          if ($exit -eq 0) { $lblStatus.Text = 'Done.'; Append-Log 'OK: Download completed.' }
          else { $lblStatus.Text = "Failed ($exit)."; Append-Log "FAIL: Exit code $exit" }
        })
      }
    })
    $timer.Start()
  }

  function Cancel-Download {
    if ($process -and -not $process.HasExited) {
      try { $process.Kill(); Append-Log 'Cancelled by user.' } catch { Append-Log "Cancel error: $_" }
    }
    $btnStart.Enabled = $true
    $btnCancel.Enabled = $false
    $lblStatus.Text = 'Cancelled.'
  }

  function Probe-Url {
    if (-not (Ensure-Binaries)) { return }
    $url = $txtUrl.Text.Trim(); if (-not $url) { return }
    Append-Log 'Probing URL...'
    $args = @('--print','title','--','{0}' -f $url)
    $p = Start-Process -FilePath (Join-Path $PSScriptRoot 'yt-dlp.exe') -ArgumentList $args -NoNewWindow -Wait -PassThru -RedirectStandardOutput (New-TemporaryFile)
  }

  # === Events ===
  $btnPaste.Add_Click({ if ([Windows.Forms.Clipboard]::ContainsText()) { $txtUrl.Text = [Windows.Forms.Clipboard]::GetText() } })
  $btnBrowseOut.Add_Click({
    $dlg = New-Object System.Windows.Forms.FolderBrowserDialog
    $dlg.SelectedPath = $txtOutDir.Text
    if ($dlg.ShowDialog() -eq 'OK') { $txtOutDir.Text = $dlg.SelectedPath }
  })
  $btnOpenOut.Add_Click({ if (Test-Path $txtOutDir.Text) { Start-Process explorer $txtOutDir.Text } })
  $btnStart.Add_Click({ Start-Download })
  $btnCancel.Add_Click({ Cancel-Download })
  $btnTestCookies.Add_Click({
    if (-not (Ensure-Binaries)) { return }
    $browser = $cmbBrowser.SelectedItem.ToString()
    if ($browser -eq 'auto') { $browser = 'chrome' }
    Append-Log "Testing cookies-from-browser $browser ..."
    $p = Start-Process -FilePath (Join-Path $PSScriptRoot 'yt-dlp.exe') -ArgumentList "--cookies-from-browser $browser --print ok" -NoNewWindow -Wait -PassThru
    if ($p.ExitCode -eq 0) { Append-Log 'OK: Cookies available.' } else { Append-Log 'FAIL: Cookies not available.' }
  })
  $btnTestUrl.Add_Click({
    if (-not (Ensure-Binaries)) { return }
    $url = $txtUrl.Text.Trim(); if (-not $url) { return }
    try {
      $psi = New-Object System.Diagnostics.ProcessStartInfo
      $psi.FileName = (Join-Path $PSScriptRoot 'yt-dlp.exe')
      $psi.Arguments = "--print title -- $url"
      $psi.RedirectStandardOutput = $true
      $psi.UseShellExecute = $false
      $p = [System.Diagnostics.Process]::Start($psi)
      $title = $p.StandardOutput.ReadToEnd()
      $p.WaitForExit()
      if ($title) { [System.Windows.Forms.MessageBox]::Show("Title:`r`n" + $title.Trim(),'URL Info') | Out-Null }
      else { [System.Windows.Forms.MessageBox]::Show('Could not read title.','URL Info') | Out-Null }
    } catch { Append-Log "Probe error: $_" }
  })

  $txtUrl.Add_DragEnter({ if ($_.Data.GetDataPresent([Windows.Forms.DataFormats]::Text)) { $_.Effect = 'Copy' } })
  $txtUrl.Add_DragDrop({ $txtUrl.Text = $_.Data.GetData([Windows.Forms.DataFormats]::Text) })

  $form.Add_Shown({ $null = Ensure-Binaries })

  # Add controls
  $form.Controls.AddRange(@($lblUrl,$txtUrl,$btnPaste,$btnTestUrl,$lblOutDir,$txtOutDir,$btnBrowseOut,$btnOpenOut,$grpOptions,$grpCookies,$grpRun,$txtLog))
  $grpOptions.Controls.AddRange(@($lblQuality,$cmbQuality,$chkThumb,$chkNoMtime,$lblFileName,$txtTemplate,$chkArchive,$chkRestrict,$chkFragments))
  $grpCookies.Controls.AddRange(@($chkUseCookies,$cmbBrowser,$btnTestCookies,$lblYtdlp,$lblYtdlpPath))
  $grpRun.Controls.AddRange(@($btnStart,$btnCancel,$lblStatus))

  return $form
}

# === Main ===
try {
  $form = New-Form
  [void]$form.ShowDialog()
} catch {
  [System.Windows.Forms.MessageBox]::Show($_.Exception.Message, 'Fatal Error') | Out-Null
}
