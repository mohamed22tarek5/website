@echo off
setlocal EnableDelayedExpansion
chcp 65001 >nul 2>&1

:: ============================================================
::  M.T.A. Win11 Defender Tool v2.0 - Full Control Menu
::  Windows 10 / 11 - Requires Administrator
:: ============================================================
title M.T.A. Win11 Defender Tool v2.0
color 0B

set "VERSION=2.0"
set "LOG=%TEMP%\MTA_Defender_Tool.log"
set "BACKUP_DIR=%TEMP%\MTA_Defender_Backup"
if not exist "%BACKUP_DIR%" mkdir "%BACKUP_DIR%" 2>nul

echo [%date% %time%] === M.T.A. Tool v%VERSION% started === >> "%LOG%"

:: ---------- Auto-elevate to Admin ----------
net session >nul 2>&1
if %errorlevel% neq 0 (
    cls
    echo [*] Requesting Administrator rights...
    powershell -NoProfile -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
    exit /b 0
)

:: ---------- OS Check ----------
for /f "delims=" %%A in ('powershell -NoProfile -Command "(Get-CimInstance Win32_OperatingSystem).Caption" 2^>nul') do set "OSNAME=%%A"
echo [%date% %time%] OS: !OSNAME! >> "%LOG%"

:menu
cls
color 0B
echo ============================================================
echo   M.T.A. WIN11 DEFENDER TOOL  v%VERSION%
echo   %OSNAME%
echo ============================================================
echo   Log: %LOG%
echo ------------------------------------------------------------
echo   [1] Check Defender Status
echo   [2] Create Restore Point + Backup Registry
echo   [3] Disable Defender  (Reversible - RECOMMENDED)
echo   [4] Enable Defender   (Restore Protection)
echo   [5] DELETE Defender   (PERMANENT - DANGER)
echo   [6] Toggle Defender Scheduled Tasks On/Off
echo   [0] Exit
echo ------------------------------------------------------------
set /p "choice=  Select option [0-6]: "

if "%choice%"=="1" goto status
if "%choice%"=="2" goto backup
if "%choice%"=="3" goto disable
if "%choice%"=="4" goto enable
if "%choice%"=="5" goto delete_warn
if "%choice%"=="6" goto tasks_menu
if "%choice%"=="0" goto end
echo [!] Invalid choice.
timeout /t 1 >nul
goto menu

:: ============================================================
:status
cls
echo ============================================================
echo   DEFENDER STATUS
echo ============================================================
echo.
call :check_tamper
echo.
echo --- Services ---
for %%S in (WinDefend WdNisSvc WdBoot WdFilter WdNisDrv Sense SecurityHealthService) do (
    sc query "%%S" 2>nul | findstr /i "STATE SERVICE_NAME FAILED" >nul 2>&1
    if !errorlevel!==0 (
        for /f "tokens=3" %%Q in ('sc query "%%S" 2^>nul ^| findstr /i "STATE"') do echo   %%S : %%Q
    ) else (
        echo   %%S : NOT FOUND / DELETED
    )
)
echo.
echo --- Real-time Protection (needs Tamper OFF to be accurate) ---
powershell -NoProfile -Command "try { $s=Get-MpComputerStatus -ErrorAction Stop; Write-Host ('  AntivirusEnabled : '+$s.AntivirusEnabled); Write-Host ('  RealTimeProtectionEnabled : '+$s.RealTimeProtectionEnabled); Write-Host ('  TamperProtectionSource : '+$s.TamperProtectionSource); Write-Host ('  DefenderVersion : '+$s.AntivirusSignatureVersion) } catch { Write-Host '  [!] Defender WMI/PS interface unavailable (removed or blocked).' }" 2>nul
echo.
echo --- Policies ---
reg query "HKLM\SOFTWARE\Policies\Microsoft\Windows Defender" /v DisableAntiSpyware 2>nul || echo   DisableAntiSpyware : not set [Defender default ON]
reg query "HKLM\SOFTWARE\Policies\Microsoft\Windows Defender\Real-Time Protection" /v DisableRealtimeMonitoring 2>nul || echo   DisableRealtimeMonitoring : not set
echo.
echo --- Scheduled Tasks ---
schtasks /query /tn "Microsoft\Windows\Windows Defender\Windows Defender Scheduled Scan" 2>nul >nul && echo   Scheduled Scan : EXISTS || echo   Scheduled Scan : MISSING/DISABLED
echo.
pause
goto menu

:: ============================================================
:check_tamper
echo --- Tamper Protection ---
reg query "HKLM\SOFTWARE\Microsoft\Windows Defender\Features" /v TamperProtection 2>nul
if %errorlevel%==0 (
    for /f "tokens=3" %%V in ('reg query "HKLM\SOFTWARE\Microsoft\Windows Defender\Features" /v TamperProtection 2^>nul ^| findstr /i "TamperProtection"') do (
        if "%%V"=="0x5" (
            echo   [!] Tamper Protection is ON.
            echo       Turn it OFF first: Windows Security ^> Virus ^& threat
            echo       protection ^> Manage settings ^> Tamper Protection = Off
            echo       Otherwise Disable/Delete steps WILL FAIL or revert.
        ) else (
            echo   [OK] Tamper Protection appears OFF [value %%V].
        )
    )
) else (
    echo   [?] Tamper Protection key not readable [Defender removed or no access].
)
exit /b 0

:: ============================================================
:backup
cls
echo ============================================================
echo   BACKUP - Restore Point + Registry
echo ============================================================
echo.
echo [*] Creating System Restore Point...
powershell -NoProfile -Command "try { Checkpoint-Computer -Description 'MTA Defender Tool Backup' -RestorePointType 'MODIFY_SETTINGS' -ErrorAction Stop; Write-Host '  [OK] Restore point created.' } catch { Write-Host ('  [!] Restore point failed: '+$_.Exception.Message) }" 2>nul
echo.
echo [*] Exporting Defender registry keys to %BACKUP_DIR%...
reg export "HKLM\SOFTWARE\Microsoft\Windows Defender" "%BACKUP_DIR%\Windows_Defender.reg" /y 2>nul && echo   [OK] Windows_Defender.reg || echo   [--] skipped [key missing]
reg export "HKLM\SOFTWARE\Policies\Microsoft\Windows Defender" "%BACKUP_DIR%\Policies_Windows_Defender.reg" /y 2>nul && echo   [OK] Policies_Windows_Defender.reg || echo   [--] skipped
reg export "HKLM\SYSTEM\CurrentControlSet\Services\WinDefend" "%BACKUP_DIR%\Svc_WinDefend.reg" /y 2>nul && echo   [OK] Svc_WinDefend.reg || echo   [--] skipped
reg export "HKLM\SYSTEM\CurrentControlSet\Services\WdFilter" "%BACKUP_DIR%\Svc_WdFilter.reg" /y 2>nul
reg export "HKLM\SYSTEM\CurrentControlSet\Services\WdBoot" "%BACKUP_DIR%\Svc_WdBoot.reg" /y 2>nul
reg export "HKLM\SYSTEM\CurrentControlSet\Services\WdNisSvc" "%BACKUP_DIR%\Svc_WdNisSvc.reg" /y 2>nul
reg export "HKLM\SYSTEM\CurrentControlSet\Services\WdNisDrv" "%BACKUP_DIR%\Svc_WdNisDrv.reg" /y 2>nul
echo.
echo [*] Backup folder: %BACKUP_DIR%
echo [%date% %time%] Backup completed >> "%LOG%"
echo.
pause
goto menu

:: ============================================================
:disable
cls
color 0E
echo ============================================================
echo   DISABLE DEFENDER (Reversible)
echo ============================================================
echo.
call :check_tamper
echo.
echo This will: stop services, set group policies, turn off
echo real-time monitoring, and DISABLE (not delete) tasks.
echo Reversible via option [4].
echo.
set /p "c=Continue? (Y/N): "
if /i not "%c%"=="Y" goto menu

echo [%date% %time%] Disable started >> "%LOG%"
echo.
echo [1/5] Stopping services...
for %%S in (WinDefend WdNisSvc Sense SecurityHealthService) do (
    net stop "%%S" /y 2>nul
    sc stop "%%S" 2>nul
    echo   - %%S stop attempted
)
echo.
echo [2/5] Applying Disable policies...
REG ADD "HKLM\SOFTWARE\Policies\Microsoft\Windows Defender" /v DisableAntiSpyware /t REG_DWORD /d 1 /f >> "%LOG%" 2>&1
REG ADD "HKLM\SOFTWARE\Policies\Microsoft\Windows Defender\Real-Time Protection" /v DisableRealtimeMonitoring /t REG_DWORD /d 1 /f >> "%LOG%" 2>&1
REG ADD "HKLM\SOFTWARE\Policies\Microsoft\Windows Defender\Real-Time Protection" /v DisableBehaviorMonitoring /t REG_DWORD /d 1 /f >> "%LOG%" 2>&1
REG ADD "HKLM\SOFTWARE\Policies\Microsoft\Windows Defender\Real-Time Protection" /v DisableOnAccessProtection /t REG_DWORD /d 1 /f >> "%LOG%" 2>&1
REG ADD "HKLM\SOFTWARE\Policies\Microsoft\Windows Defender\Real-Time Protection" /v DisableScanOnRealtimeEnable /t REG_DWORD /d 1 /f >> "%LOG%" 2>&1
REG ADD "HKLM\SOFTWARE\Policies\Microsoft\Windows Defender\Real-Time Protection" /v DisableIOAVProtection /t REG_DWORD /d 1 /f >> "%LOG%" 2>&1
REG ADD "HKLM\SOFTWARE\Policies\Microsoft\Windows Defender\Spynet" /v DisableBlockAtFirstSeen /t REG_DWORD /d 1 /f >> "%LOG%" 2>&1
echo   [OK] Policies applied.
echo.
echo [3/5] PowerShell preferences (requires Tamper OFF)...
powershell -NoProfile -Command "try { Set-MpPreference -DisableRealtimeMonitoring $true -DisableBehaviorMonitored $true -DisableBlockAtFirstSeen $true -DisableIOAVProtection $true -DisableScriptScanning $true -ErrorAction Stop; Write-Host '  [OK] MpPreference updated.' } catch { Write-Host ('  [!] Set-MpPreference failed (Tamper likely ON): '+$_.Exception.Message) }" 2>nul
echo.
echo [4/5] Disabling scheduled tasks (reversible)...
for %%T in ("Windows Defender Cache Maintenance" "Windows Defender Cleanup" "Windows Defender Scheduled Scan" "Windows Defender Verification") do (
    schtasks /Change /TN "Microsoft\Windows\Windows Defender\%%~T" /Disable 2>nul && echo   [OK] Disabled %%~T || echo   [--] %%~T not found/already off
)
echo.
echo [5/5] Disabling SecurityHealth startup...
REG ADD "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Explorer" /v HideSCAHealth /t REG_DWORD /d 1 /f >nul 2>&1
echo   [OK] Done.
echo.
echo [%date% %time%] Disable finished >> "%LOG%"
color 0A
echo ============================================================
echo   DEFENDER DISABLED. Restart recommended.
echo   Use option [4] to re-enable.
echo ============================================================
pause
goto menu

:: ============================================================
:enable
cls
color 0A
echo ============================================================
echo   ENABLE DEFENDER (Restore Protection)
echo ============================================================
echo.
set /p "c=Continue? (Y/N): "
if /i not "%c%"=="Y" goto menu

echo [%date% %time%] Enable started >> "%LOG%"
echo.
echo [1/4] Removing Disable policies...
REG DELETE "HKLM\SOFTWARE\Policies\Microsoft\Windows Defender" /v DisableAntiSpyware /f 2>nul
REG DELETE "HKLM\SOFTWARE\Policies\Microsoft\Windows Defender\Real-Time Protection" /v DisableRealtimeMonitoring /f 2>nul
REG DELETE "HKLM\SOFTWARE\Policies\Microsoft\Windows Defender\Real-Time Protection" /v DisableBehaviorMonitoring /f 2>nul
REG DELETE "HKLM\SOFTWARE\Policies\Microsoft\Windows Defender\Real-Time Protection" /v DisableOnAccessProtection /f 2>nul
REG DELETE "HKLM\SOFTWARE\Policies\Microsoft\Windows Defender\Real-Time Protection" /v DisableScanOnRealtimeEnable /f 2>nul
REG DELETE "HKLM\SOFTWARE\Policies\Microsoft\Windows Defender\Real-Time Protection" /v DisableIOAVProtection /f 2>nul
REG ADD "HKLM\SOFTWARE\Policies\Microsoft\Windows Defender" /v DisableAntiSpyware /t REG_DWORD /d 0 /f >nul 2>&1
REG DELETE "HKLM\SOFTWARE\Policies\Microsoft\Windows Defender" /v DisableAntiSpyware /f 2>nul
echo   [OK] Policies cleared.
echo.
echo [2/4] Restoring services to Auto...
for %%S in (WinDefend WdNisSvc SecurityHealthService) do (
    sc config "%%S" start= auto 2>nul
    sc start "%%S" 2>nul
    if !errorlevel! equ 0 (
        echo   [OK] %%S started
    ) else (
        echo   [--] %%S start failed [reboot may fix]
    )
)
for %%D in (WdBoot WdFilter WdNisDrv) do sc config "%%D" start= boot 2>nul
sc config WdFilter start= boot 2>nul
sc config WdNisDrv start= manual 2>nul
echo.
echo [3/4] Re-enabling scheduled tasks...
for %%T in ("Windows Defender Cache Maintenance" "Windows Defender Cleanup" "Windows Defender Scheduled Scan" "Windows Defender Verification") do (
    schtasks /Change /TN "Microsoft\Windows\Windows Defender\%%~T" /Enable 2>nul && echo   [OK] Enabled %%~T || echo   [--] %%~T not found
)
echo.
echo [4/4] Restoring Security Center + MpPreference...
REG DELETE "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Explorer" /v HideSCAHealth /f 2>nul
powershell -NoProfile -Command "try { Set-MpPreference -DisableRealtimeMonitoring $false -DisableBehaviorMonitored $false -DisableBlockAtFirstSeen $false -DisableIOAVProtection $false -DisableScriptScanning $false -ErrorAction Stop; Write-Host '  [OK] MpPreference restored.' } catch { Write-Host ('  [!] Set-MpPreference failed: '+$_.Exception.Message) }" 2>nul
echo.
echo [%date% %time%] Enable finished >> "%LOG%"
echo ============================================================
echo   DEFENDER RESTORED. Restart + Update signatures in
echo   Windows Security.
echo ============================================================
pause
goto menu

:: ============================================================
:delete_warn
cls
color 0C
echo ============================================================
echo   !!! PERMANENT DELETE - IRREVERSIBLE !!!
echo ============================================================
echo.
echo This PERMANENTLY removes Defender files, services,
echo drivers, tasks and registry keys. You will need to
echo REINSTALL WINDOWS to get it back.
echo.
echo STRONGLY recommended: use option [2] backup + option [3]
echo disable instead.
echo.
set /p "c1=Type DELETE in caps to continue (anything else aborts): "
if not "%c1%"=="DELETE" (
    echo Aborted.
    timeout /t 1 >nul
    goto menu
)
echo.
set /p "c2=Last chance. Really delete? (Y/N): "
if /i not "%c2%"=="Y" goto menu
goto delete_run

:delete_run
cls
color 0C
echo [%date% %time%] DELETE started >> "%LOG%"
set "PASS=0"
set "FAIL=0"

echo [1/7] Stopping services...
for %%S in (WinDefend WdNisSvc WdBoot WdFilter WdNisDrv Sense SecurityHealthService) do sc stop "%%S" 2>nul
timeout /t 2 >nul
echo   done.

echo [2/7] Deleting services...
for %%S in (WinDefend WdBoot WdFilter WdNisDrv WdNisSvc Sense SecurityHealthService) do (
    sc delete "%%S" >nul 2>&1
    set "ERR=!errorlevel!"
    if !ERR! equ 0 (
        echo   [OK] %%S
        set /a PASS+=1
    ) else (
        echo   [--] %%S - not found or access denied
        set /a FAIL+=1
    )
    echo [!date! !time!] sc delete %%S err=!ERR! >> "%LOG%"
)

echo [3/7] Deleting scheduled tasks...
set "TASKBASE=Microsoft\Windows\Windows Defender"
for %%T in ("Windows Defender Cache Maintenance" "Windows Defender Cleanup" "Windows Defender Scheduled Scan" "Windows Defender Verification" "Windows Defender Idle Scan" "Windows Defender Reporting") do (
    schtasks /Delete /TN "%TASKBASE%\%%~T" /F >nul 2>&1
    if !errorlevel! equ 0 (
        echo   [OK] %%~T
        set /a PASS+=1
    ) else (
        echo   [--] %%~T - not found
        set /a FAIL+=1
    )
)

echo [4/7] Registry removal [backup in %BACKUP_DIR%]...
REG DELETE "HKLM\SOFTWARE\Microsoft\Windows Defender" /f 2>nul
REG DELETE "HKLM\SOFTWARE\Policies\Microsoft\Windows Defender" /f 2>nul
REG DELETE "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Image File Execution Options\MSASCui.exe" /f 2>nul
REG DELETE "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Image File Execution Options\MsMpEng.exe" /f 2>nul
REG DELETE "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Image File Execution Options\MpCmdRun.exe" /f 2>nul
REG DELETE "HKCR\*\shellex\ContextMenuHandlers\EPP" /f 2>nul
REG DELETE "HKCR\Directory\shellex\ContextMenuHandlers\EPP" /f 2>nul
REG DELETE "HKCR\Drive\shellex\ContextMenuHandlers\EPP" /f 2>nul
echo   done. See log for details.

echo [5/7] Taking ownership of files...
takeown /f "C:\Program Files\Windows Defender" /r /d y >nul 2>&1
icacls "C:\Program Files\Windows Defender" /grant administrators:F /t /q >nul 2>&1
takeown /f "C:\ProgramData\Microsoft\Windows Defender" /r /d y >nul 2>&1
icacls "C:\ProgramData\Microsoft\Windows Defender" /grant administrators:F /t /q >nul 2>&1
for %%F in (WdFilter.sys WdNisDrv.sys WdBoot.sys) do (
    takeown /f "C:\Windows\System32\drivers\%%F" >nul 2>&1
    icacls "C:\Windows\System32\drivers\%%F" /grant administrators:F >nul 2>&1
)
echo   done.

echo [6/7] Deleting files and folders...
rmdir /s /q "C:\Program Files\Windows Defender" 2>nul
if %errorlevel% equ 0 (echo   [OK] Program Files\Windows Defender) else echo   [--] locked/missing [reboot + retry]
rmdir /s /q "C:\ProgramData\Microsoft\Windows Defender" 2>nul && echo   [OK] ProgramData Defender || echo   [--] locked/missing
for %%F in (WdFilter.sys WdNisDrv.sys WdBoot.sys) do del /f /q "C:\Windows\System32\drivers\%%F" 2>nul
echo   drivers attempted.
powershell -NoProfile -Command "try { Get-CimInstance -Namespace root/SecurityCenter2 -ClassName AntiVirusProduct -ErrorAction Stop | Remove-CimInstance -ErrorAction Stop; Write-Host '  [OK] SecurityCenter2 WMI cleared.' } catch { Write-Host '  [--] WMI clear skipped/failed.' }" 2>nul

echo [7/7] Applying Disable policies to block reinstall/restart...
REG ADD "HKLM\SOFTWARE\Policies\Microsoft\Windows Defender" /v DisableAntiSpyware /t REG_DWORD /d 1 /f >nul 2>&1
REG ADD "HKLM\SOFTWARE\Policies\Microsoft\Windows Defender\Real-Time Protection" /v DisableRealtimeMonitoring /t REG_DWORD /d 1 /f >nul 2>&1
echo   done.

echo.
echo ============================================================
echo   DELETE COMPLETE. Passed: !PASS!  Skipped/Failed: !FAIL!
echo   Log: %LOG%
echo ============================================================
echo   [!] System has NO antivirus. Install one NOW.
echo   [!] RESTART required for full effect.
echo ============================================================
echo [%date% %time%] DELETE finished PASS=!PASS! FAIL=!FAIL! >> "%LOG%"
echo.
set /p "rb=Restart now? (Y/N): "
if /i "%rb%"=="Y" shutdown /r /t 10 /c "MTA Tool: Defender removed. No antivirus protection!"
goto menu

:: ============================================================
:tasks_menu
cls
echo ============================================================
echo   SCHEDULED TASKS ON/OFF
echo ============================================================
echo   [1] Disable all Defender tasks
echo   [2] Enable all Defender tasks
echo   [B] Back
echo ------------------------------------------------------------
set /p "tc=Choice: "
if /i "%tc%"=="B" goto menu
if "%tc%"=="1" (
    for %%T in ("Windows Defender Cache Maintenance" "Windows Defender Cleanup" "Windows Defender Scheduled Scan" "Windows Defender Verification") do schtasks /Change /TN "Microsoft\Windows\Windows Defender\%%~T" /Disable 2>nul
    echo Disabled.
    pause
    goto menu
)
if "%tc%"=="2" (
    for %%T in ("Windows Defender Cache Maintenance" "Windows Defender Cleanup" "Windows Defender Scheduled Scan" "Windows Defender Verification") do schtasks /Change /TN "Microsoft\Windows\Windows Defender\%%~T" /Enable 2>nul
    echo Enabled.
    pause
    goto menu
)
goto tasks_menu

:: ============================================================
:end
echo.
echo Log saved to %LOG%
echo Backup in %BACKUP_DIR%
timeout /t 2 >nul
exit /b 0
