# Code M.T.A. Tweaking Utility – License Agreement

**Copyright © 2025 Code M.T.A. TWEAKS, S.R.O.®

All rights reserved.**

This software is provided free of charge for **personal, non-commercial use** only. By downloading, copying, or using this script (Code M.T.A. Tweaking.cmd), you agree to the following terms:

---

## ✅ Permitted Use

- You may use this script **for personal purposes only**.
- You may review and study the code.
- You may modify the script **for personal use only** on your own devices.

---

## ❌ Restrictions

- **Commercial use**, redistribution, or integration into other products or services is **strictly prohibited** without prior written permission from the author.
- You **may not sell**, license, sublicense, or otherwise commercially exploit this script.
- You **may not publicly share** modified versions without written authorization.
- You **may not remove** or obscure any copyright, trademark, or attribution notices.

---

## ⚠️ Disclaimer

This script is provided **"as is"**, without warranty of any kind.  
Use at your own risk. The author assumes no responsibility for damage to systems, data loss, or any other impact resulting from the use of this software.

---

## 📬 Contact for Commercial Licensing

For business inquiries or to request permission for redistribution or commercial use, please contact:

**Code M.T.A. TWEAKS, S.R.O.®**  
Email: [medoteto2252003@gmail.com]  
Website: [https://website-mohamed.vercel.app/]

