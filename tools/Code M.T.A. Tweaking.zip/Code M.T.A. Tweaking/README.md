# Code M.T.A. Tweaking Utility

A free Windows system tweaking script developed by **Code M.T.A. TWEAKS, S.R.O.® 2025**.  
It automates system-level and MTA:SA client tweaks to enhance performance, stability, and usability.

---

## 🔧 What It Does

This script automates a collection of system and game-specific optimizations aimed at improving performance for both the **Multi Theft Auto: San Andreas (MTA:SA)** client and the host Windows environment.

### 🎮 MTA:SA Tweaks

- **Network Performance Optimization**  
  Adjusts settings like `cl_packetRate` and `cl_cmdRate` to reduce lag and improve synchronization.

- **Graphics Settings Adjustment**  
  Optimizes game visuals for better performance, ideal for low-end or mid-range PCs.

- **Input and Control Behavior**  
  Enhances mouse and input configuration for more responsive aiming and smoother control.

- **Shader and Anti-Aliasing Modifications**  
  Disables or reduces effects that commonly lower FPS.

---

### 🛠️ System-Level Enhancements

- **Maximized Command Prompt**  
  Script forces the CMD window to launch in full-screen for better usability.

- **ANSI Escape Sequence Support**  
  Enables colored terminal output using Windows Virtual Terminal Processing.

- **User SID Detection**  
  Retrieves the current user’s **Security Identifier (SID)** for accurate registry operations.

- **System Restore Configuration**  
  - Enables System Restore on `C:\`
  - Deletes registry restrictions:
    - `RPSessionInterval`
    - `DisableConfig`
  - Sets `SystemRestorePointCreationFrequency` to `0` to allow frequent restore points.

---

## 📋 How to Use It

1. **Download** the file: `Code M.T.A. Tweaking.cmd`
2. **Right-click** the file and choose **Run as Administrator**
3. A full-screen command prompt will open automatically
4. The script will apply all tweaks without user intervention

> 🛑 **Important:** Admin rights are required.  
> ⚠️ This script makes system registry changes — proceed with caution and consider creating a manual restore point.

---

## ✅ Requirements

- Windows 10 or Windows 11 (64-bit)
- Administrator privileges
- PowerShell 5.0 or newer *(preinstalled on modern Windows versions)*

---

## 🔄 Before & After Tweaks

| Feature                     | Before Running Script           | After Running Script                |
|----------------------------|----------------------------------|-------------------------------------|
| Command Prompt Behavior    | Default window size             | Always opens maximized              |
| ANSI Colors in Terminal    | Not supported                   | Color output enabled                |
| System Restore             | May be disabled                 | Enabled and unrestricted            |
| Restore Point Frequency    | Limited to once per 24 hours    | Can create at any time              |

---

## 🧪 Tested On

- ✅ Windows 10 Pro (x64)
- ✅ Windows 11 Home (x64)
- ❌ Not tested on Windows 7 or older


